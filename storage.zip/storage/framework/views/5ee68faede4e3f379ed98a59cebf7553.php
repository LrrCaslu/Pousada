<?php $__env->startSection('title','Calendário de ocupação'); ?>
<?php $__env->startSection('content'); ?>
<div class="ux-page ux-secondary-page">
    <?php echo $__env->make('admin.partials.module-hero', ['eyebrow' => 'CONTROLE DE OCUPAÇÃO', 'title' => 'Calendário de hospedagens', 'description' => 'Acompanhe as estadias por mês e selecione datas para consultar os detalhes.', 'photo' => 'piscina-iluminada.webp'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="bi-heading cs-calendar-heading">
    <div><span class="bi-eyebrow">GESTÃO DE HOSPEDAGENS / OCUPAÇÃO</span><h1>Calendário <span>de ocupação</span></h1><p>Visualize as estadias por dia, consulte disponibilidade e acompanhe as chegadas.</p></div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reservations')): ?><a class="bi-button bi-button-dark" href="<?php echo e(route('admin.reservations.create')); ?>">＋ Nova reserva</a><?php endif; ?>
</div>
<div class="cs-calendar-layout">
  <section class="cs-calendar-card" aria-label="Calendário mensal">
    <div class="cs-calendar-toolbar"><div class="cs-calendar-nav"><button type="button" id="csCalPrev" aria-label="Mês anterior">‹</button><button type="button" id="csCalToday">Hoje</button><button type="button" id="csCalNext" aria-label="Próximo mês">›</button></div><h2 id="csCalTitle" aria-live="polite">Carregando calendário...</h2><label class="cs-calendar-filter">Quarto <select id="csCalRoom"><option value="">Todos os quartos</option><?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($room->number); ?>">Quarto <?php echo e($room->number); ?> — <?php echo e($room->type?->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label></div>
    <div class="cs-calendar-weekdays" aria-hidden="true"><span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span><span>Dom</span></div>
    <div id="reservation-calendar" class="cs-calendar-grid" data-url="<?php echo e(route('admin.calendar.events')); ?>" role="grid" aria-label="Dias do mês"><p class="cs-calendar-loading">Carregando reservas do banco de dados...</p></div>
    <div class="cs-calendar-legend"><span><i class="cs-color-confirmed"></i> Confirmada</span><span><i class="cs-color-checkin"></i> Em hospedagem</span><span><i class="cs-color-pending"></i> Pendente</span><span><i class="cs-color-other"></i> Outros estados</span></div>
  </section>
  <aside class="cs-calendar-aside" aria-live="polite"><span class="bi-eyebrow">PROGRAMAÇÃO DO DIA</span><h2 id="csCalSelectedTitle">Selecione uma data</h2><div id="csCalDayEvents"><p>Escolha um dia no calendário para consultar as reservas.</p></div><a class="cs-calendar-action" href="<?php echo e(route('admin.dashboard')); ?>">↗ Voltar ao dashboard</a></aside>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\admin\calendar.blade.php ENDPATH**/ ?>