<article class="room-card cs-room-card">
    <a class="cs-room-image" href="<?php echo e(route('rooms.show', $type->slug)); ?>" aria-label="Ver <?php echo e($type->name); ?>">
        <img src="<?php echo e($type->cover_image ? asset('storage/' . $type->cover_image) : asset('assets/photos/quarto-' . (($type->id - 1) % 5 + 1) . '.webp')); ?>" alt="Acomodação <?php echo e($type->name); ?> — imagem ilustrativa" loading="lazy">
        <span class="cs-room-image-label">ESTADIA ESPECIAL</span>
    </a>
    <div class="room-card-body">
        <h3><a href="<?php echo e(route('rooms.show', $type->slug)); ?>"><?php echo e($type->name); ?></a></h3>
        <div class="room-facts"><span>♙ Até <?php echo e($type->capacity); ?> hóspedes</span><span>▤ <?php echo e($type->beds); ?> <?php echo e($type->beds === 1 ? 'cama' : 'camas'); ?></span><span>✧ <?php echo e($type->view ?: 'Aconchego'); ?></span></div>
        <div class="room-card-bottom"><span>A partir de <strong>R$ <?php echo e(number_format((float) $type->base_rate, 2, ',', '.')); ?></strong> / diária</span><a class="cs-room-button" href="<?php echo e(route('rooms.show', $type->slug)); ?>">Ver detalhes <span aria-hidden="true">→</span></a></div>
    </div>
</article>
<?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\partials\type-card.blade.php ENDPATH**/ ?>