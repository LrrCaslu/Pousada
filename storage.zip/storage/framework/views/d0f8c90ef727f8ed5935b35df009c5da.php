<?php $__env->startSection('title', 'Imagens do site'); ?>
<?php $__env->startSection('content'); ?>
<div class="media-admin">
  <div class="bi-heading"><div><span class="bi-eyebrow"><span class="bi-pulse"></span> IDENTIDADE VISUAL / MÍDIAS LOCAIS</span><h1>Imagens <span>do site</span></h1><p>Escolha a foto principal da homepage e consulte a coleção de imagens do projeto.</p></div><a class="bi-button bi-button-outline" href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener">↗ Visualizar site</a></div>
  <div class="media-admin-banner"><img src="<?php echo e(asset('assets/photos/' . $selected)); ?>" id="mediaHeroPreview" alt="Prévia da foto principal da homepage"><div class="media-admin-shade"><span>PRÉ-VISUALIZAÇÃO DO BANNER</span><strong>Sua pousada, sua melhor primeira impressão.</strong><small id="mediaPreviewLabel"><?php echo e($photos[$selected]); ?></small></div></div>
  <form action="<?php echo e(route('admin.media.update')); ?>" method="POST" id="mediaLibraryForm">
    <?php echo csrf_field(); ?>
    <div class="media-admin-tools"><div><h2>Biblioteca de fotografias</h2><p>Imagens ilustrativas geradas para demonstração. Selecione uma para o banner principal.</p></div><button class="bi-button bi-button-dark" type="submit">✓ Salvar imagem principal</button></div>
    <div class="media-admin-grid">
    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filename => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <label class="media-choice <?php echo e($selected === $filename ? 'is-selected' : ''); ?>">
        <input type="radio" name="hero_photo" value="<?php echo e($filename); ?>" <?php echo e($selected === $filename ? 'checked' : ''); ?> data-hero-url="<?php echo e(asset('assets/photos/' . $filename)); ?>" data-photo-label="<?php echo e($label); ?>">
        <img src="<?php echo e(asset('assets/photos/' . $filename)); ?>" alt="<?php echo e($label); ?>" loading="lazy">
        <span class="media-choice-label"><span><?php echo e($label); ?></span><span class="media-choice-mark">✓</span></span>
      </label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <p class="media-admin-note">As fotografias são ilustrativas e não retratam uma propriedade real. A seleção modifica somente a imagem da homepage. Fotos específicas de acomodações podem ser enviadas na área <a href="<?php echo e(route('admin.rooms.index')); ?>">Acomodações</a>.</p>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\admin\media\index.blade.php ENDPATH**/ ?>