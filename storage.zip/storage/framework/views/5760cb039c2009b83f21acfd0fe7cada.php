<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $icons = asset('assets/icons-admin.svg');
    $firstName = \Illuminate\Support\Str::before(auth()->user()->name, ' ');
    $greeting = now()->hour < 12 ? 'Bom dia' : (now()->hour < 18 ? 'Boa tarde' : 'Boa noite');
    $periodText = ['7d' => 'Últimos 7 dias', '30d' => 'Últimos 30 dias', '90d' => 'Últimos 90 dias', 'month' => 'Este mês', 'custom' => 'Período personalizado'][$period] ?? 'Últimos 30 dias';
    $statusStops = [];
    foreach ($statusGroups as $group) {
        if ($group['count'] > 0) {
            $statusStops[] = $group['color'].' '.$group['start'].'% '.$group['end'].'%';
        }
    }
    $statusGradient = count($statusStops) ? 'conic-gradient('.implode(', ', $statusStops).')' : 'conic-gradient(#e9eeeb 0% 100%)';
    $paymentStops = [];
    foreach ($paymentGroups as $group) {
        if ($group['amount'] > 0) {
            $paymentStops[] = $group['color'].' '.$group['start'].'% '.$group['end'].'%';
        }
    }
    $paymentGradient = count($paymentStops) ? 'conic-gradient('.implode(', ', $paymentStops).')' : 'conic-gradient(#e9eeeb 0% 100%)';
?>
<div class="ref-dashboard">
    <section class="ref-dashboard-heading">
        <div>
            <span class="ref-overline">PAINEL DE DESEMPENHO · COSTA SERENA</span>
            <h1>Painel Administrativo</h1>
            <p class="ref-greeting"><?php echo e($greeting); ?>, <?php echo e($firstName); ?>! <span aria-hidden="true">👋</span></p>
            <p class="ref-subtitle">Indicadores do banco de dados · atualizados ao abrir esta página.</p>
        </div>
        <details class="ref-period-menu" id="refPeriodMenu">
            <summary><svg class="ref-icon"><use href="<?php echo e($icons); ?>#calendar"></use></svg><span>Período: <strong><?php echo e($periodText); ?></strong></span><svg class="ref-icon ref-chevron"><use href="<?php echo e($icons); ?>#chevron-down"></use></svg></summary>
            <div class="ref-period-popover">
                <strong>Filtrar período</strong>
                <div class="ref-period-choices">
                    <?php $__currentLoopData = ['7d' => 'Últimos 7 dias', '30d' => 'Últimos 30 dias', '90d' => 'Últimos 90 dias', 'month' => 'Este mês']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.dashboard', ['period' => $key])); ?>" class="<?php echo e($period === $key ? 'is-selected' : ''); ?>" <?php if($period === $key): ?> aria-current="page" <?php endif; ?>><?php echo e($label); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <form method="GET" action="<?php echo e(route('admin.dashboard')); ?>" class="ref-custom-period">
                    <input type="hidden" name="period" value="custom">
                    <label>De<input type="date" name="start" value="<?php echo e($startDate); ?>" max="<?php echo e(now()->toDateString()); ?>" required></label>
                    <label>Até<input type="date" name="end" value="<?php echo e($endDate); ?>" max="<?php echo e(now()->toDateString()); ?>" required></label>
                    <button type="submit">Aplicar período</button>
                </form>
                <p>De <?php echo e(\Carbon\Carbon::parse($startDate)->format('d/m/Y')); ?> até <?php echo e(\Carbon\Carbon::parse($endDate)->format('d/m/Y')); ?>.</p>
            </div>
        </details>
    </section>

    <section class="ref-kpis" aria-label="Indicadores principais">
        <article class="ref-kpi ref-kpi-reservations">
            <span class="ref-kpi-icon"><svg class="ref-icon"><use href="<?php echo e($icons); ?>#calendar-check"></use></svg></span>
            <span class="ref-kpi-name">Reservas</span>
            <strong class="ref-kpi-number"><?php echo e(number_format($reservationsCount, 0, ',', '.')); ?></strong>
            <div class="ref-kpi-bottom">
                <small>Registradas no período</small>
                <?php if($previousReservations > 0): ?>
                    <?php
                        $reservationVariation = ($reservationsCount - $previousReservations) * 100 / $previousReservations;
                    ?>
                    <span class="ref-kpi-change <?php echo e($reservationVariation < 0 ? 'is-negative' : ''); ?>"><?php echo e($reservationVariation < 0 ? '↘' : '↗'); ?> <?php echo e(number_format(abs($reservationVariation), 1, ',', '.')); ?>%</span>
                <?php else: ?>
                    <span class="ref-kpi-chip">Dados reais</span>
                <?php endif; ?>
            </div>
        </article>
        <article class="ref-kpi ref-kpi-occupancy">
            <span class="ref-kpi-icon"><svg class="ref-icon"><use href="<?php echo e($icons); ?>#bed"></use></svg></span>
            <span class="ref-kpi-name">Ocupação Média</span>
            <strong class="ref-kpi-number"><?php echo e(number_format($occupancyAverage, 1, ',', '.')); ?>%</strong>
            <div class="ref-kpi-bottom"><small>No período escolhido</small><span class="ref-kpi-chip"><?php echo e($totalRooms); ?> quartos</span></div>
        </article>
        <article class="ref-kpi ref-kpi-guests">
            <span class="ref-kpi-icon"><svg class="ref-icon"><use href="<?php echo e($icons); ?>#users"></use></svg></span>
            <span class="ref-kpi-name">Hóspedes</span>
            <strong class="ref-kpi-number"><?php echo e(number_format($totalGuests, 0, ',', '.')); ?></strong>
            <div class="ref-kpi-bottom"><small>Total cadastrado</small><span class="ref-kpi-chip">+<?php echo e($newGuests); ?> no período</span></div>
        </article>
        <article class="ref-kpi ref-kpi-revenue">
            <span class="ref-kpi-icon"><svg class="ref-icon"><use href="<?php echo e($icons); ?>#dollar"></use></svg></span>
            <?php if($canFinance): ?>
                <span class="ref-kpi-name">Receita (período)</span>
                <strong class="ref-kpi-number ref-currency">R$ <?php echo e(number_format($received, 2, ',', '.')); ?></strong>
                <div class="ref-kpi-bottom"><small>Recebimentos no período</small>
                    <?php if($previousReceived > 0): ?>
                        <?php
                            $receivedVariation = ($received - $previousReceived) * 100 / $previousReceived;
                        ?>
                        <span class="ref-kpi-change <?php echo e($receivedVariation < 0 ? 'is-negative' : ''); ?>"><?php echo e($receivedVariation < 0 ? '↘' : '↗'); ?> <?php echo e(number_format(abs($receivedVariation), 1, ',', '.')); ?>%</span>
                    <?php else: ?>
                        <span class="ref-kpi-chip">Simulado</span>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <span class="ref-kpi-name">Check-ins hoje</span>
                <strong class="ref-kpi-number"><?php echo e($arrivalToday); ?></strong>
                <div class="ref-kpi-bottom"><small>Chegadas previstas</small><span class="ref-kpi-chip">Hoje</span></div>
            <?php endif; ?>
        </article>
    </section>

    
    <section class="v52-operational" aria-labelledby="v52TodayTitle">
        <div class="v52-operational-heading">
            <div><span class="v52-eyebrow">ROTINA DA POUSADA</span><h2 id="v52TodayTitle">O que acontece hoje</h2></div>
            <span class="v52-date"><svg class="ref-icon" aria-hidden="true"><use href="<?php echo e($icons); ?>#calendar"></use></svg><?php echo e(now()->format('d/m/Y')); ?></span>
        </div>
        <div class="v52-operational-grid">
            <?php if($canReservations): ?>
                <a class="v52-operational-item v52-arrivals" href="<?php echo e(route('admin.calendar')); ?>" aria-label="Consultar no calendário os <?php echo e($arrivalToday); ?> check-ins previstos para hoje">
                    <span class="v52-operational-icon"><svg class="ref-icon" aria-hidden="true"><use href="<?php echo e($icons); ?>#calendar-check"></use></svg></span>
                    <span class="v52-operational-copy"><span>Check-ins previstos</span><strong><?php echo e($arrivalToday); ?></strong><small>Hoje · consultar calendário</small></span>
                    <span class="v52-operational-arrow" aria-hidden="true">↗</span>
                </a>
                <a class="v52-operational-item v52-departures" href="<?php echo e(route('admin.calendar')); ?>" aria-label="Consultar no calendário os <?php echo e($departureToday); ?> check-outs previstos para hoje">
                    <span class="v52-operational-icon"><svg class="ref-icon" aria-hidden="true"><use href="<?php echo e($icons); ?>#bed"></use></svg></span>
                    <span class="v52-operational-copy"><span>Check-outs previstos</span><strong><?php echo e($departureToday); ?></strong><small>Hoje · consultar calendário</small></span>
                    <span class="v52-operational-arrow" aria-hidden="true">↗</span>
                </a>
                <a class="v52-operational-item v52-pending <?php echo e($pending > 0 ? 'has-attention' : ''); ?>" href="<?php echo e(route('admin.reservations.index')); ?>" aria-label="Consultar <?php echo e($pending); ?> reservas pendentes">
                    <span class="v52-operational-icon"><svg class="ref-icon" aria-hidden="true"><use href="<?php echo e($icons); ?>#clock"></use></svg></span>
                    <span class="v52-operational-copy"><span>Reservas pendentes</span><strong><?php echo e($pending); ?></strong><small><?php echo e($pending > 0 ? 'Precisam de acompanhamento' : 'Nenhuma pendência ativa'); ?></small></span>
                    <span class="v52-operational-arrow" aria-hidden="true">↗</span>
                </a>
            <?php endif; ?>
            <?php if($canHousekeeping): ?>
                <a class="v52-operational-item v52-housekeeping" href="<?php echo e(route('admin.housekeeping.index')); ?>" aria-label="Consultar <?php echo e($cleaningPending); ?> tarefas de governança pendentes">
                    <span class="v52-operational-icon"><svg class="ref-icon" aria-hidden="true"><use href="<?php echo e($icons); ?>#broom"></use></svg></span>
                    <span class="v52-operational-copy"><span>Limpezas pendentes</span><strong><?php echo e($cleaningPending); ?></strong><small>Equipe de governança</small></span>
                    <span class="v52-operational-arrow" aria-hidden="true">↗</span>
                </a>
            <?php endif; ?>
            <?php if(!$canReservations && !$canHousekeeping): ?>
                <div class="v52-operational-item v52-summary">
                    <span class="v52-operational-icon"><svg class="ref-icon" aria-hidden="true"><use href="<?php echo e($icons); ?>#chart"></use></svg></span>
                    <span class="v52-operational-copy"><span>Resumo disponível</span><strong><?php echo e($reservationsCount); ?></strong><small>Reservas registradas no período</small></span>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <div class="ref-dashboard-grid ref-top-analytics">
        <section class="ref-panel ref-occupancy-panel">
            <div class="ref-panel-heading"><h2>Evolução da Ocupação</h2><a class="v52-panel-link" href="<?php echo e(route('admin.calendar')); ?>">Ver calendário <span aria-hidden="true">↗</span></a></div>
            <div class="ref-chart-legend"><span><i class="ref-dot ref-dot-green"></i> Ocupação (%)</span><span><i class="ref-dot ref-dot-mint"></i> Quartos ocupados</span></div>
            <div class="ref-occupancy-tools" aria-label="Escala do gráfico de ocupação">
                <span class="ref-scale-badge" id="refOccupancyScale" aria-live="polite">Escala real</span>
                <button type="button" id="refOccupancyZoom" class="ref-scale-toggle" aria-pressed="false" hidden>Ampliar leitura</button>
            </div>
            <div class="ref-svg-chart" data-ref-chart="occupancy" role="img" aria-label="Evolução da ocupação percentual e do número de quartos ocupados em cada dia"><span class="ref-chart-placeholder">Preparando gráfico...</span></div>
            <p class="ref-chart-caption" id="refOccupancyCaption" aria-live="polite">Escala calculada com base nos quartos ativos e nas reservas do período.</p>
        </section>
        <section class="ref-panel ref-status-panel">
            <div class="ref-panel-heading"><h2>Status das Reservas</h2><?php if($canReservations): ?><a class="v52-panel-link" href="<?php echo e(route('admin.reservations.index')); ?>">Ver reservas <span aria-hidden="true">↗</span></a><?php endif; ?></div>
            <div class="ref-donut-layout">
                <div class="ref-donut cs-status-donut" style="background:<?php echo e($statusGradient); ?>" role="img" aria-label="Distribuição de <?php echo e($reservationsCount); ?> reservas por status"><div class="ref-donut-hole"><strong><?php echo e($reservationsCount); ?></strong><small>Reservas</small></div></div>
                <div class="ref-donut-legend">
                    <?php $__currentLoopData = $statusGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><span><i style="background:<?php echo e($group['color']); ?>"></i><?php echo e($group['name']); ?></span><strong><?php echo e(number_format($group['percentage'], 1, ',', '.')); ?>% <small>(<?php echo e($group['count']); ?>)</small></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <p class="v52-context-note">Distribuição das reservas registradas no período selecionado.</p>
        </section>
    </div>

    <div class="ref-dashboard-grid ref-mid-analytics">
        <section class="ref-panel ref-arrivals-panel">
            <div class="ref-panel-heading"><h2>Próximas Chegadas <small>(Check-in)</small></h2><a href="<?php echo e(route('admin.calendar')); ?>">Ver todas <svg class="ref-icon"><use href="<?php echo e($icons); ?>#arrow-right"></use></svg></a></div>
            <div class="ref-arrivals-list">
                <?php if($canReservations): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $upcoming->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="ref-arrival">
                            <span class="ref-guest-avatar"><?php echo e(mb_strtoupper(mb_substr($booking->guest?->name ?? 'H', 0, 1))); ?><?php echo e(mb_strtoupper(mb_substr(\Illuminate\Support\Str::after($booking->guest?->name ?? ' ', ' '), 0, 1))); ?></span>
                            <span class="ref-arrival-info"><strong><?php echo e($booking->guest?->name ?? 'Hóspede'); ?></strong><small><?php echo e($booking->check_in->isToday() ? 'Hoje' : $booking->check_in->format('d/m')); ?> · <?php echo e($booking->rooms->pluck('number')->join(', ') ?: 'Acomodação'); ?></small></span>
                            <a class="ref-chip ref-chip-success" href="<?php echo e(route('admin.reservations.show', $booking)); ?>"><?php echo e($booking->status === 'checkin' ? 'Hospedado' : 'Confirmada'); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="ref-empty">Não há chegadas confirmadas para os próximos dias.</div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="ref-empty">Agenda de hóspedes disponível para a recepção.</div>
                <?php endif; ?>
            </div>
        </section>
        <section class="ref-panel ref-rooms-panel">
            <div class="ref-panel-heading"><h2>Acomodações</h2><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-rooms')): ?><a class="v52-panel-link" href="<?php echo e(route('admin.rooms.index')); ?>">Gerenciar <span aria-hidden="true">↗</span></a><?php endif; ?></div>
            <p class="ref-panel-meta"><?php echo e($totalRooms); ?> quartos ativos</p>
            <div class="ref-room-states">
                <div><strong class="ref-state-num ref-state-available"><?php echo e($availableToday); ?></strong><span>Disponíveis</span><svg class="ref-icon"><use href="<?php echo e($icons); ?>#bed"></use></svg></div>
                <div><strong class="ref-state-num ref-state-occupied"><?php echo e($occupiedToday); ?></strong><span>Ocupados</span></div>
                <div><strong class="ref-state-num ref-state-maintenance"><?php echo e($blockedToday); ?></strong><span>Em manutenção / bloqueio</span></div>
            </div>
            <?php if($totalRooms > 0): ?>
                <div class="v52-capacity" aria-label="Distribuição dos <?php echo e($totalRooms); ?> quartos ativos: <?php echo e($availableToday); ?> disponíveis, <?php echo e($occupiedToday); ?> ocupados, <?php echo e($blockedToday); ?> bloqueados">
                    <div class="v52-capacity-track" role="img" aria-label="<?php echo e($availableToday); ?> disponíveis, <?php echo e($occupiedToday); ?> ocupados, <?php echo e($blockedToday); ?> bloqueados, de <?php echo e($totalRooms); ?> quartos">
                        <span class="v52-capacity-available" style="width:<?php echo e(round(100 * $availableToday / $totalRooms, 2)); ?>%"></span>
                        <span class="v52-capacity-occupied" style="width:<?php echo e(round(100 * $occupiedToday / $totalRooms, 2)); ?>%"></span>
                        <span class="v52-capacity-blocked" style="width:<?php echo e(round(100 * $blockedToday / $totalRooms, 2)); ?>%"></span>
                    </div>
                    <small>Distribuição de disponibilidade hoje</small>
                </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-rooms')): ?><a href="<?php echo e(route('admin.rooms.index')); ?>" class="ref-card-footer-link">Gerenciar acomodações <svg class="ref-icon"><use href="<?php echo e($icons); ?>#arrow-right"></use></svg></a><?php endif; ?>
        </section>
        <section class="ref-panel ref-payment-panel">
            <?php if($canFinance): ?>
                <div class="ref-panel-heading"><h2>Recebimentos por Método</h2><a class="v52-panel-link" href="<?php echo e(route('admin.finance.index')); ?>">Financeiro <span aria-hidden="true">↗</span></a></div>
                <div class="ref-donut-layout ref-small-donut-layout">
                    <div class="ref-donut ref-small-donut" style="background:<?php echo e($paymentGradient); ?>" role="img" aria-label="Distribuição dos pagamentos aprovados por método"><div class="ref-donut-hole"><strong>R$ <?php echo e(number_format($received, 0, ',', '.')); ?></strong><small>Recebidos</small></div></div>
                    <div class="ref-donut-legend">
                        <?php $__empty_1 = true; $__currentLoopData = $paymentGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div><span><i style="background:<?php echo e($group['color']); ?>"></i><?php echo e($group['name']); ?></span><strong><?php echo e(number_format($group['percentage'], 1, ',', '.')); ?>%</strong></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="ref-empty">Sem recebimentos no período.</div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="ref-panel-heading"><h2>Operação de Hoje</h2></div>
                <div class="ref-today-operations"><div><svg class="ref-icon"><use href="<?php echo e($icons); ?>#calendar-check"></use></svg><span>Check-ins previstos</span><strong><?php echo e($arrivalToday); ?></strong></div><div><svg class="ref-icon"><use href="<?php echo e($icons); ?>#calendar"></use></svg><span>Check-outs previstos</span><strong><?php echo e($departureToday); ?></strong></div><div><svg class="ref-icon"><use href="<?php echo e($icons); ?>#clock"></use></svg><span>Reservas pendentes</span><strong><?php echo e($pending); ?></strong></div></div>
            <?php endif; ?>
        </section>
    </div>

    <div class="ref-dashboard-grid ref-bottom-analytics">
        <section class="ref-panel ref-monthly-panel">
            <div class="ref-panel-heading"><h2><?php echo e($monthlyChartTitle); ?></h2><?php if($canFinance): ?><a class="v52-panel-link" href="<?php echo e(route('admin.reports')); ?>">Relatórios <span aria-hidden="true">↗</span></a><?php elseif($canReservations): ?><a class="v52-panel-link" href="<?php echo e(route('admin.reservations.index')); ?>">Ver reservas <span aria-hidden="true">↗</span></a><?php endif; ?></div>
            <div class="ref-svg-chart ref-monthly-chart" data-ref-chart="monthly" role="img" aria-label="<?php echo e($monthlyChartTitle); ?> calculada a partir do banco de dados"><span class="ref-chart-placeholder">Preparando gráfico...</span></div>
            <?php if($canFinance): ?><small class="ref-hint">Pagamentos aprovados no modo de demonstração, não transações bancárias reais.</small><?php endif; ?>
        </section>
        <section class="ref-panel ref-roomrates-panel">
            <div class="ref-panel-heading"><h2>Taxa de Ocupação por Acomodação</h2><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-rooms')): ?><a class="v52-panel-link" href="<?php echo e(route('admin.rooms.index')); ?>">Acomodações <span aria-hidden="true">↗</span></a><?php endif; ?></div>
            <div class="ref-roomrate-list">
                <?php $__empty_1 = true; $__currentLoopData = $roomOccupancy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="ref-roomrate-row"><span title="<?php echo e($type['name']); ?>"><?php echo e($type['name']); ?></span><div class="ref-roomrate-track"><span style="width:<?php echo e($type['percentage']); ?>%"></span></div><strong><?php echo e(number_format($type['percentage'], 1, ',', '.')); ?>%</strong></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="ref-empty">Cadastre quartos para visualizar a ocupação por categoria.</div>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <section class="ref-actions-footer" aria-label="Ações rápidas">
        <span>Atalhos</span>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reservations')): ?><a href="<?php echo e(route('admin.reservations.create')); ?>"><svg class="ref-icon"><use href="<?php echo e($icons); ?>#plus"></use></svg> Nova reserva</a><?php endif; ?>
        <a href="<?php echo e(route('admin.calendar')); ?>"><svg class="ref-icon"><use href="<?php echo e($icons); ?>#calendar"></use></svg> Calendário</a>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-settings')): ?><a href="<?php echo e(route('admin.pages.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($icons); ?>#layer"></use></svg> Editar páginas</a><?php endif; ?>
        <button type="button" id="biExportCsv"><svg class="ref-icon"><use href="<?php echo e($icons); ?>#upload"></use></svg> Exportar indicadores CSV</button>
    </section>
    <p class="ref-data-footnote">Indicadores consultados no banco MySQL. Reservas por data de criação; ocupação por noites; disponibilidade atual considera os bloqueios cadastrados. A apresentação se adapta às permissões do usuário.</p>
</div>
<script type="application/json" id="bi-dashboard-data"><?php echo json_encode($chartData, 15, 512) ?></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>