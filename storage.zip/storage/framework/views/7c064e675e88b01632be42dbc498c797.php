<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#173e34">
    <title><?php echo $__env->yieldContent('title', 'Pousada Costa Serena'); ?> · <?php echo e(\App\Models\Setting::read('pousada_nome', 'Pousada Costa Serena')); ?></title>
    <meta name="description" content="Pousada Costa Serena — conforto, natureza e experiências inesquecíveis em uma estadia acolhedora.">
    <?php if(file_exists(public_path('build/manifest.json'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/app.css')); ?>">
        <script src="<?php echo e(asset('assets/app.js')); ?>" defer></script>
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/site-enhancements.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/costa-site-v3.css')); ?>?v=3">
    <script src="<?php echo e(asset('assets/site-enhancements.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/costa-ui-v3.js')); ?>?v=3" defer></script>
</head>
<body class="cs-site">
    <header class="site-header cs-site-header">
        <div class="wrap cs-nav">
            <a class="brand cs-brand" href="<?php echo e(route('home')); ?>" aria-label="Pousada Costa Serena — início">
                <img src="<?php echo e(asset('assets/brand.svg')); ?>" alt="" width="60" height="48">
                <span><?php echo e(\App\Models\Setting::read('pousada_nome', 'Pousada Costa Serena')); ?></span>
            </a>
            <button id="csMenuToggle" class="cs-menu-toggle" type="button" aria-controls="csMenu" aria-expanded="false" aria-label="Abrir menu de navegação">☰</button>
            <nav class="cs-navlinks" id="csMenu" aria-label="Menu principal">
                <a class="<?php echo e(request()->routeIs('home') ? 'is-current' : ''); ?>" href="<?php echo e(route('home')); ?>">Início</a>
                <a class="<?php echo e(request()->routeIs('rooms.*') ? 'is-current' : ''); ?>" href="<?php echo e(route('rooms.index')); ?>">Acomodações</a>
                <a href="<?php echo e(route('page.show', 'experiencias')); ?>">Experiências</a>
                <a href="<?php echo e(route('page.show', 'sobre')); ?>">A pousada</a>
                <a href="<?php echo e(route('page.show', 'galeria')); ?>">Galeria</a>
                <a href="<?php echo e(route('contact')); ?>">Contato</a>
            </nav>
            <div class="cs-nav-actions">
                <?php if(auth()->guard()->check()): ?>
                    <a class="cs-account-link" href="<?php echo e(auth()->user()->hasRole('hospede') ? route('guest.dashboard') : route('admin.dashboard')); ?>">♙ <span>Minha área</span></a>
                <?php else: ?>
                    <a class="cs-account-link" href="<?php echo e(route('login')); ?>">♙ <span>Minha Reserva</span></a>
                <?php endif; ?>
                <a class="cs-reserve-top" href="<?php echo e(route('rooms.index')); ?>">▣ <span>Reservar agora</span></a>
            </div>
        </div>
    </header>
    <?php if(session('success')): ?>
        <div class="wrap alert success" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="wrap alert error" role="alert"><strong>Revise os dados:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
    <?php endif; ?>
    <main id="main"><?php echo $__env->yieldContent('content'); ?></main>
    <footer class="footer cs-footer">
        <div class="wrap footer-grid">
            <div><a class="brand cs-brand cs-footer-brand" href="<?php echo e(route('home')); ?>"><img width="55" src="<?php echo e(asset('assets/brand.svg')); ?>" alt=""><span><?php echo e(\App\Models\Setting::read('pousada_nome', 'Pousada Costa Serena')); ?></span></a><p>Conforto, natureza e hospitalidade. Sua próxima pausa começa aqui.</p><small>Projeto fictício e imagens ilustrativas para demonstração local.</small></div>
            <div><strong>Explore</strong><a href="<?php echo e(route('rooms.index')); ?>">Acomodações</a><a href="<?php echo e(route('page.show', 'sobre')); ?>">Nossa história</a><a href="<?php echo e(route('page.show', 'experiencias')); ?>">Experiências</a><a href="<?php echo e(route('page.show', 'galeria')); ?>">Galeria</a></div>
            <div><strong>Informações</strong><a href="<?php echo e(route('page.show', 'cancelamento')); ?>">Cancelamentos</a><a href="<?php echo e(route('page.show', 'termos')); ?>">Termos de uso</a><a href="<?php echo e(route('page.show', 'privacidade')); ?>">Privacidade</a><a href="<?php echo e(route('contact')); ?>">Contato</a></div>
        </div>
        <div class="wrap footer-bottom">© <?php echo e(date('Y')); ?> Pousada Costa Serena · Ambiente de demonstração</div>
    </footer>
    <?php
        $whatsapp = preg_replace('/\D/', '', \App\Models\Setting::read('whatsapp', ''));
    ?>
    <?php if($whatsapp): ?>
        <a class="wa-float" rel="noopener noreferrer" target="_blank" href="https://wa.me/<?php echo e($whatsapp); ?>" aria-label="Fale conosco pelo WhatsApp">✆</a>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\layouts\site.blade.php ENDPATH**/ ?>