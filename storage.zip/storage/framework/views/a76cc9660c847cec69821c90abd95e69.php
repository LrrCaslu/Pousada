<?php $__env->startSection('title', 'Reservas'); ?>
<?php $__env->startSection('content'); ?>
<div class="ux-page" data-ux-module="reservas">
    <?php echo $__env->make('admin.partials.module-hero', ['eyebrow' => 'HOSPEDAGEM / ATENDIMENTO', 'title' => 'Central de reservas', 'description' => 'Acompanhe suas hospedagens, confirme solicitações e consulte cada reserva.', 'photo' => 'hero-costa-serena.webp'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php
        $reservationRows = $reservations->getCollection();
        $visibleConfirmed = $reservationRows->whereIn('status', ['confirmada','checkin','checkout'])->count();
        $visiblePending = $reservationRows->whereIn('status', ['pendente','aguardando_pagamento'])->count();
        $visibleRevenue = $reservationRows->sum('total');
    ?>
    <div class="ux-heading-row"><div><span class="ux-overline">OPERAÇÃO DE RESERVAS</span><h2>Reservas e atendimento</h2><p>Indicadores dos registros carregados nesta página.</p></div><a class="ux-btn ux-btn-primary" href="<?php echo e(route('admin.reservations.create')); ?>"><span aria-hidden="true">＋</span> Nova reserva</a></div>
    <div class="ux-metrics ux-metrics-three">
        <article class="ux-metric"><span class="ux-metric-icon ux-green">▤</span><span>Reservas nesta página</span><strong><?php echo e($reservationRows->count()); ?></strong><small><?php echo e(number_format($reservations->total(), 0, ',', '.')); ?> no resultado da busca</small></article>
        <article class="ux-metric"><span class="ux-metric-icon ux-gold">◷</span><span>Confirmadas / em hospedagem</span><strong><?php echo e($visibleConfirmed); ?></strong><small><?php echo e($visiblePending); ?> pendentes nesta página</small></article>
        <article class="ux-metric"><span class="ux-metric-icon ux-blue">R$</span><span>Valor das reservas listadas</span><strong class="ux-currency">R$ <?php echo e(number_format($visibleRevenue, 2, ',', '.')); ?></strong><small>Total de reservas carregadas, não é receita recebida</small></article>
    </div>
    <section class="ux-panel">
        <div class="ux-panel-heading"><div><span class="ux-overline">LOCALIZAR E ORGANIZAR</span><h3>Lista de reservas</h3><p>Use os filtros para pesquisar no banco de dados.</p></div><span class="ux-panel-count"><?php echo e($reservations->total()); ?> registros</span></div>
        <form class="ux-toolbar" method="GET" action="<?php echo e(route('admin.reservations.index')); ?>">
            <label class="ux-search"><span class="sr-only">Buscar por código ou hóspede</span><span aria-hidden="true">⌕</span><input name="search" value="<?php echo e(request('search')); ?>" placeholder="Código da reserva ou nome do hóspede" autocomplete="off"></label>
            <label class="ux-select-wrap"><span class="sr-only">Situação da reserva</span><select name="status"><option value="">Todos os status</option><?php $__currentLoopData = ['pendente' => 'Pendente', 'aguardando_pagamento' => 'Aguardando pagamento', 'confirmada' => 'Confirmada', 'checkin' => 'Check-in realizado', 'checkout' => 'Check-out realizado', 'cancelada' => 'Cancelada', 'nao_compareceu' => 'Não compareceu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($key); ?>" <?php if(request('status') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <button class="ux-btn ux-btn-primary" type="submit">Pesquisar</button>
            <?php if(request()->filled('search') || request()->filled('status')): ?><a class="ux-btn ux-btn-light" href="<?php echo e(route('admin.reservations.index')); ?>">Limpar</a><?php endif; ?>
        </form>
        <div class="ux-table-wrap"><table class="ux-table"><thead><tr><th>Reserva</th><th>Hóspede</th><th>Acomodação</th><th>Check-in</th><th>Check-out</th><th>Situação</th><th class="ux-align-right">Valor</th><th class="ux-align-right">Ação</th></tr></thead><tbody>
            <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr><td><a class="ux-code-link" href="<?php echo e(route('admin.reservations.show', $r)); ?>">#<?php echo e($r->code); ?></a></td><td><strong><?php echo e($r->guest?->name ?? 'Hóspede indisponível'); ?></strong></td><td><?php echo e($r->rooms->pluck('number')->join(', ') ?: '—'); ?></td><td><?php echo e($r->check_in->format('d/m/Y')); ?></td><td><?php echo e($r->check_out->format('d/m/Y')); ?></td><td><span class="ux-status" data-status="<?php echo e($r->status); ?>"><?php echo e(str_replace('_', ' ', $r->status)); ?></span></td><td class="ux-align-right ux-nowrap">R$ <?php echo e(number_format($r->total, 2, ',', '.')); ?></td><td class="ux-align-right"><a class="ux-text-action" href="<?php echo e(route('admin.reservations.show', $r)); ?>">Detalhes ›</a></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="8"><div class="ux-empty"><strong>Nenhuma reserva encontrada</strong><span>Experimente outros filtros ou cadastre uma nova reserva.</span></div></td></tr><?php endif; ?>
        </tbody></table></div>
        <div class="ux-pagination"><?php echo e($reservations->links()); ?></div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views/admin/reservations/index.blade.php ENDPATH**/ ?>