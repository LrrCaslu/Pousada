<section class="ux-hero" aria-labelledby="ux-page-title">
    <img class="ux-hero-image" src="<?php echo e(asset('assets/photos/' . ($photo ?? 'praia-e-pousada.webp'))); ?>" alt="" loading="lazy">
    <div class="ux-hero-copy">
        <span class="ux-hero-eyebrow"><span class="ux-pulse"></span><?php echo e($eyebrow ?? 'GESTÃO DA POUSADA'); ?></span>
        <h1 id="ux-page-title"><?php echo e($title); ?></h1>
        <p><?php echo e($description ?? ''); ?></p>
    </div>
    <div class="ux-hero-glow" aria-hidden="true"></div>
</section>
<?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\admin\partials\module-hero.blade.php ENDPATH**/ ?>