<?php $__env->startSection('title', 'Páginas do site'); ?>
<?php $__env->startSection('content'); ?>
<?php
    // Dados derivados no próprio template evitam erros quando o cache de views estiver desatualizado.
    $publishedCount = $publishedCount ?? $pages->where('published', true)->count();
    $draftCount = $draftCount ?? $pages->count() - $publishedCount;
    $selected = $selected ?? ($pages->firstWhere('id', (int) request('page')) ?? $pages->first());
?>
<div class="editor-page">
    <div class="cs-page-header-photo"><img src="<?php echo e(asset('assets/photos/praia-e-pousada.webp')); ?>" alt="Paisagem costeira ilustrativa"><div><strong>O conteúdo da sua pousada, em boas mãos.</strong><small>Edite informações institucionais e organize sua presença digital.</small></div></div>
    <div class="bi-heading editor-heading">
        <div><div class="bi-eyebrow"><span class="bi-pulse"></span> CENTRAL DE CONTEÚDO <span class="bi-separator">/</span> SITE PÚBLICO</div><h1>Páginas <span>do site</span></h1><p>Organize, atualize e publique o conteúdo institucional da pousada.</p></div>
        <div class="editor-heading-links"><a class="bi-button bi-button-outline" href="<?php echo e(route('admin.media.index')); ?>">▧ Imagens do site</a><a class="bi-button bi-button-outline" href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener noreferrer">↗ Abrir site público</a></div>
    </div>

    <div class="editor-stat-grid">
        <div class="editor-stat"><span class="editor-stat-icon">▤</span><div><strong><?php echo e($pages->count()); ?></strong><small>Páginas cadastradas</small></div></div>
        <div class="editor-stat"><span class="editor-stat-icon editor-green">●</span><div><strong><?php echo e($publishedCount); ?></strong><small>Publicadas no site</small></div></div>
        <div class="editor-stat"><span class="editor-stat-icon editor-amber">◒</span><div><strong><?php echo e($draftCount); ?></strong><small>Não publicadas</small></div></div>
    </div>

    <?php if($selected): ?>
        <div class="editor-workspace">
            <aside class="editor-list" aria-label="Lista de páginas">
                <div class="editor-list-head"><div><span class="bi-eyebrow">BIBLIOTECA</span><h2>Suas páginas</h2></div><span class="editor-counter"><?php echo e($pages->count()); ?></span></div>
                <button type="button" class="cs-new-page" id="csNewPage" aria-haspopup="dialog">＋ Nova página</button>
                <label class="editor-search"><span aria-hidden="true">⌕</span><input type="search" id="pageSearch" placeholder="Buscar por título ou URL" autocomplete="off" aria-label="Buscar páginas"></label>
                <nav class="editor-page-list">
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.pages.index', ['page' => $page->id])); ?>" class="editor-list-item <?php echo e($selected->id === $page->id ? 'is-active' : ''); ?>" data-page-filter="<?php echo e(mb_strtolower($page->title . ' ' . $page->slug)); ?>" <?php if($selected->id === $page->id): ?> aria-current="page" <?php endif; ?>>
                            <span class="editor-list-icon"><?php echo e(str_pad((string)$loop->iteration, 2, '0', STR_PAD_LEFT)); ?></span>
                            <span class="editor-list-text"><strong><?php echo e($page->title); ?></strong><small>/pagina/<?php echo e($page->slug); ?></small></span>
                            <span class="editor-indicator <?php echo e($page->published ? 'is-published' : 'is-draft'); ?>" title="<?php echo e($page->published ? 'Publicada' : 'Não publicada'); ?>"></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </nav>
                <div class="editor-list-empty" id="pageSearchEmpty" hidden>Nenhuma página encontrada.</div>
                <div class="editor-list-hint">As páginas são cadastradas no sistema. Aqui você pode editar o conteúdo e controlar sua publicação.</div>
            </aside>

            <main class="editor-main">
                <div class="editor-main-top">
                    <div><span class="bi-eyebrow">EDITANDO PÁGINA</span><h2><?php echo e($selected->title); ?></h2><div class="editor-meta"><code>/pagina/<?php echo e($selected->slug); ?></code><span>·</span><span>Atualizada em <?php echo e($selected->updated_at?->format('d/m/Y \à\s H:i') ?? '—'); ?></span></div></div>
                    <span class="editor-badge <?php echo e($selected->published ? 'is-published' : 'is-draft'); ?>"><?php echo e($selected->published ? '● Publicada' : '◒ Não publicada'); ?></span>
                </div>
                <div class="editor-tabs" role="tablist" aria-label="Modo de edição"><button class="editor-tab is-current" id="editorTabWrite" type="button" role="tab" aria-selected="true" aria-controls="editorWrite">✎ Editor</button><button class="editor-tab" id="editorTabPreview" type="button" role="tab" aria-selected="false" aria-controls="editorPreview">▣ Pré-visualização</button></div>

                <form method="POST" action="<?php echo e(route('admin.pages.update', $selected)); ?>" id="pageEditForm" class="editor-form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div id="editorWrite" role="tabpanel" aria-labelledby="editorTabWrite">
                        <div class="cs-editor-media-info"><img src="<?php echo e(asset('assets/photos/hero-costa-serena.webp')); ?>" alt="Imagem ilustrativa de destaque"><div><strong>Identidade visual do site</strong><small>Fotografias do site são gerenciadas separadamente do texto desta página.</small><a href="<?php echo e(route('admin.media.index')); ?>">Abrir biblioteca de imagens ↗</a></div></div>
                        <div class="editor-field"><label for="pageTitle">Título da página <span>*</span></label><input id="pageTitle" name="title" type="text" value="<?php echo e(old('title', $selected->title)); ?>" maxlength="180" required autocomplete="off"><small>Este título aparece no topo da página pública.</small></div>
                        <div class="editor-field"><label for="pageBody">Conteúdo principal</label><textarea id="pageBody" name="body" rows="15" maxlength="40000" placeholder="Escreva o conteúdo desta página..."><?php echo e(old('body', $selected->body)); ?></textarea><div class="editor-field-foot"><span>Texto simples. Quebras de linha serão preservadas na página pública.</span><span id="pageCharCount">0 / 40.000 caracteres</span></div></div>
                        <div class="editor-publish-box"><div class="editor-publish-info"><strong>Publicação da página</strong><p>Quando não publicada, a página deixa de aparecer na URL pública. A pré-visualização continua disponível aqui.</p></div><label class="editor-switch"><input id="pagePublished" type="checkbox" <?php echo e(old('published', $selected->published) ? 'checked' : ''); ?>><span class="editor-switch-track"></span><span class="editor-switch-label" id="pagePublishText"><?php echo e(old('published', $selected->published) ? 'Publicada' : 'Não publicada'); ?></span></label><input type="hidden" name="published" id="pagePublishedValue" value="<?php echo e(old('published', $selected->published) ? '1' : '0'); ?>"></div>
                    </div>
                    <div id="editorPreview" role="tabpanel" aria-labelledby="editorTabPreview" hidden>
                        <div class="editor-preview-outer"><div class="editor-preview-banner"><span>POUSADA COSTA SERENA</span><h2 id="previewTitle"><?php echo e(old('title', $selected->title)); ?></h2></div><article id="previewBody" class="editor-preview-content"></article></div><p class="editor-preview-caption">Pré-visualização local do texto. O site público aplica seu próprio layout responsivo. HTML inserido no texto não será executado.</p>
                    </div>
                    <footer class="editor-form-footer"><div class="editor-save-note"><span class="editor-save-circle"></span><span id="editorDirtyText">Alterações ainda não foram realizadas.</span></div><div class="editor-footer-actions"><?php if($selected->published): ?><a class="bi-button bi-button-outline" href="<?php echo e(route('page.show', $selected->slug)); ?>" target="_blank" rel="noopener noreferrer">↗ Ver página pública</a><?php endif; ?><button class="bi-button bi-button-outline" type="submit" name="intent" value="draft">Salvar rascunho</button><button class="bi-button bi-button-dark" type="submit" name="intent" value="publish">✓ Salvar e publicar</button></div></footer>
                </form>
            </main>
        </div>
    <?php else: ?>
        <div class="bi-panel"><div class="bi-no-data">Nenhuma página cadastrada. <button type="button" class="cs-new-page" id="csNewPage">＋ Criar primeira página</button></div></div>
    <?php endif; ?>
    <dialog class="cs-new-page-modal" id="csNewPageModal" aria-labelledby="csNewPageTitle">
        <form method="POST" action="<?php echo e(route('admin.pages.store')); ?>">
            <?php echo csrf_field(); ?>
            <header><h2 id="csNewPageTitle">Criar página do site</h2><button id="csCloseNewPage" type="button" aria-label="Fechar">✕</button></header>
            <div class="cs-modal-fields">
                <label>Título da página <input type="text" name="title" maxlength="180" required placeholder="Ex.: Eventos e encontros"></label>
                <label>Slug / endereço <input type="text" name="slug" maxlength="120" placeholder="Gerado a partir do título se vazio"><small>Endereço público: /pagina/seu-endereco</small></label>
                <label>Conteúdo inicial <textarea name="body" rows="5" maxlength="40000" placeholder="Apresente sua página..."></textarea></label>
                <label class="cs-modal-check"><input type="checkbox" name="published" value="1"> Publicar imediatamente</label>
            </div>
            <footer><button class="bi-button bi-button-outline" type="button" id="csCancelNewPage">Cancelar</button><button type="submit" class="bi-button bi-button-dark">＋ Criar página</button></footer>
        </form>
    </dialog>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\admin\pages\index.blade.php ENDPATH**/ ?>