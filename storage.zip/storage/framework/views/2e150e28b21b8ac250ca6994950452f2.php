<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#064435">
    <title><?php echo $__env->yieldContent('title', 'Painel administrativo'); ?> · Pousada Costa Serena</title>
    <?php if(file_exists(public_path('build/manifest.json'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/app.css')); ?>">
        <script src="<?php echo e(asset('assets/app.js')); ?>" defer></script>
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin-studio.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/costa-admin-v3.css')); ?>?v=3.1">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin-reference-v4.css')); ?>?v=4.1.0">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin-unified-v5.css')); ?>?v=5.0.0">
    <script src="<?php echo e(asset('assets/admin-studio.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/costa-admin-v3.js')); ?>?v=3.1" defer></script>
    <script src="<?php echo e(asset('assets/admin-reference-v4.js')); ?>?v=4.1.0" defer></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin-dashboard-v52.css')); ?>?v=5.2.0">
    <script src="<?php echo e(asset('assets/admin-unified-v5.js')); ?>?v=5.0.0" defer></script>
    <script src="<?php echo e(asset('assets/admin-dashboard-v52.js')); ?>?v=5.2.0" defer></script>
</head>
<body class="admin-body cs-admin-body cs-ref-body">
<?php
    $adminIcons = asset('assets/icons-admin.svg');
    $firstName = \Illuminate\Support\Str::before(auth()->user()->name, ' ');
?>
<div class="app-shell cs-app-shell ref-shell">
    <aside class="sidebar cs-sidebar ref-sidebar" id="csAdminSidebar" aria-label="Navegação administrativa">
        <div class="ref-sidebar-content">
            <a class="brand inverse ref-logo" href="<?php echo e(route('admin.dashboard')); ?>" aria-label="Pousada Costa Serena — Painel administrativo">
                <img src="<?php echo e(asset('assets/brand-admin.svg')); ?>" width="62" height="50" alt="">
                <span>Pousada<strong>Costa Serena</strong></span>
            </a>
            <nav class="ref-navigation" aria-label="Módulos da pousada">
                <a class="<?php echo e(request()->routeIs('admin.dashboard') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>" <?php if(request()->routeIs('admin.dashboard')): ?> aria-current="page" <?php endif; ?>>
                    <svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#home"></use></svg><span>Dashboard</span>
                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reservations')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.reservations.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.reservations.index')); ?>">
                        <svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#calendar-check"></use></svg><span>Reservas</span>
                        <?php if(isset($pending) && $pending > 0): ?>
                            <span class="ref-nav-count"><?php echo e($pending); ?></span>
                        <?php endif; ?>
                    </a>
                <?php endif; ?>
                <a class="<?php echo e(request()->routeIs('admin.calendar*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.calendar')); ?>">
                    <svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#calendar"></use></svg><span>Calendário</span>
                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-rooms')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.rooms.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.rooms.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#bed"></use></svg><span>Acomodações</span></a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reservations')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.guests.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.guests.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#users"></use></svg><span>Hóspedes</span></a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-finance')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.finance.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.finance.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#dollar"></use></svg><span>Financeiro</span><svg class="ref-icon ref-nav-chevron"><use href="<?php echo e($adminIcons); ?>#chevron-down"></use></svg></a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-settings')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.rates.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.rates.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#price-tag"></use></svg><span>Tarifas e Promoções</span></a>
                    <a class="<?php echo e(request()->routeIs('admin.pages.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.pages.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#layer"></use></svg><span>Páginas do Site</span></a>
                    <a class="<?php echo e(request()->routeIs('admin.media.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.media.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#images"></use></svg><span>Conteúdo e Mídias</span></a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-housekeeping')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.housekeeping.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.housekeeping.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#broom"></use></svg><span>Governança</span><svg class="ref-icon ref-nav-chevron"><use href="<?php echo e($adminIcons); ?>#chevron-down"></use></svg></a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-settings')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.staff.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.staff.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#user-cog"></use></svg><span>Funcionários</span></a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-finance')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.reports') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.reports')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#chart"></use></svg><span>Relatórios</span></a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-settings')): ?>
                    <a class="<?php echo e(request()->routeIs('admin.settings.*') ? 'is-active' : ''); ?>" href="<?php echo e(route('admin.settings.index')); ?>"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#settings"></use></svg><span>Configurações</span></a>
                <?php endif; ?>
            </nav>
            <div class="ref-sidebar-footer">
                <a href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener noreferrer"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#external"></use></svg> Ver site público</a>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#logout"></use></svg> Sair da conta</button>
                </form>
            </div>
        </div>
    </aside>
    <div class="admin-main cs-admin-main ref-main">
        <header class="admin-top cs-admin-top ref-topbar">
            <button type="button" id="navToggle" class="mobile-toggle ref-mobile-toggle" aria-controls="csAdminSidebar" aria-expanded="false" aria-label="Abrir menu administrativo"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#menu"></use></svg></button>
            <div class="ref-top-spacer"></div>
            <div class="admin-command cs-command ref-search">
                <button type="button" id="adminCommandToggle" class="admin-command-toggle" aria-controls="adminCommandPanel" aria-expanded="false" aria-label="Pesquisar módulos"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#search"></use></svg><span>Buscar no sistema...</span><kbd>Ctrl K</kbd></button>
                <div id="adminCommandPanel" class="admin-command-panel" hidden>
                    <label class="admin-command-field">Buscar módulo<input id="adminCommandInput" type="search" autocomplete="off" placeholder="Reservas, páginas, financeiro..."></label>
                    <nav id="adminCommandLinks" aria-label="Resultados da pesquisa">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                        <a href="<?php echo e(route('admin.calendar')); ?>">Calendário</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reservations')): ?>
                            <a href="<?php echo e(route('admin.reservations.index')); ?>">Reservas</a><a href="<?php echo e(route('admin.guests.index')); ?>">Hóspedes</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-rooms')): ?><a href="<?php echo e(route('admin.rooms.index')); ?>">Acomodações</a><?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-finance')): ?><a href="<?php echo e(route('admin.finance.index')); ?>">Financeiro</a><a href="<?php echo e(route('admin.reports')); ?>">Relatórios</a><?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-housekeeping')): ?><a href="<?php echo e(route('admin.housekeeping.index')); ?>">Governança</a><?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-settings')): ?>
                            <a href="<?php echo e(route('admin.rates.index')); ?>">Tarifas</a><a href="<?php echo e(route('admin.pages.index')); ?>">Páginas do site</a><a href="<?php echo e(route('admin.media.index')); ?>">Imagens do site</a><a href="<?php echo e(route('admin.staff.index')); ?>">Funcionários</a><a href="<?php echo e(route('admin.settings.index')); ?>">Configurações</a>
                        <?php endif; ?>
                    </nav>
                    <p id="adminCommandEmpty" hidden>Nenhum módulo encontrado.</p>
                </div>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reservations')): ?>
                <a class="ref-top-circle ref-alert-link" href="<?php echo e(route('admin.reservations.index')); ?>" aria-label="Consultar reservas pendentes" title="Reservas"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#bell"></use></svg><?php if(isset($pending) && $pending > 0): ?><i class="ref-alert-dot"></i><?php endif; ?></a>
            <?php endif; ?>
            <details class="ref-top-details ref-help-box">
                <summary class="ref-top-circle" title="Ajuda" aria-label="Ajuda"><svg class="ref-icon"><use href="<?php echo e($adminIcons); ?>#help"></use></svg></summary>
                <div class="ref-top-popover"><strong>Ajuda rápida</strong><p>Use o menu lateral para gerenciar a pousada. Pressione <kbd>Ctrl K</kbd> para localizar módulos.</p><a href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener noreferrer">Abrir o site público</a></div>
            </details>
            <details class="ref-top-details ref-profile-box">
                <summary class="ref-profile" aria-label="Abrir menu do usuário"><span class="ref-profile-avatar"><?php echo e(mb_strtoupper(mb_substr($firstName, 0, 1))); ?></span><span class="ref-profile-names"><strong><?php echo e($firstName); ?></strong><small><?php echo e(auth()->user()->role?->name ?? 'Equipe'); ?></small></span><svg class="ref-icon ref-profile-chevron"><use href="<?php echo e($adminIcons); ?>#chevron-down"></use></svg></summary>
                <div class="ref-top-popover ref-profile-popover">
                    <strong><?php echo e(auth()->user()->name); ?></strong><small><?php echo e(auth()->user()->email); ?></small>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-settings')): ?><a href="<?php echo e(route('admin.settings.index')); ?>">Configurações da pousada</a><?php endif; ?>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit">Sair da conta</button>
                    </form>
                </div>
            </details>
        </header>
        <main class="admin-content cs-admin-content ref-content" id="refMainContent">
            <?php if(session('success')): ?>
                <div class="alert success" role="status"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert error" role="alert"><strong>Revise os dados:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\layouts\admin.blade.php ENDPATH**/ ?>