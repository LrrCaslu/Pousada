<?php $__env->startSection('title', 'Conforto, natureza e exclusividade'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $availablePhotos = config('site-media.photos', []);
    $heroPhoto = \App\Models\Setting::read('site_hero_photo', config('site-media.hero_default'));
    if (!isset($availablePhotos[$heroPhoto])) {
        $heroPhoto = config('site-media.hero_default');
    }
?>

<section class="cs-hero" aria-labelledby="csHeroTitle">
    <img class="cs-hero-image" src="<?php echo e(asset('assets/photos/' . $heroPhoto)); ?>" alt="Imagem ilustrativa de pousada boutique com piscina e natureza tropical" fetchpriority="high">
    <div class="cs-hero-shade"></div>
    <div class="wrap cs-hero-inner">
        <div class="cs-hero-copy">
            <span class="cs-label-light"><span class="cs-label-line"></span> SEU REFÚGIO À BEIRA-MAR</span>
            <h1 id="csHeroTitle">Conforto, natureza<br>e <em>exclusividade</em></h1>
            <p>Um lugar para viver momentos inesquecíveis. Acolhimento, charme e tranquilidade em cada detalhe.</p>
            <a class="cs-hero-more" href="<?php echo e(route('page.show', 'sobre')); ?>">Descubra a pousada <span aria-hidden="true">↗</span></a>
        </div>
        <div class="cs-hero-side"><span>01 / 03</span><small>Viva dias extraordinários</small></div>
    </div>
</section>

<section class="cs-search-shell wrap" aria-labelledby="csBookingTitle">
    <form method="GET" action="<?php echo e(route('rooms.index')); ?>" class="cs-search-card" id="csQuickBooking">
        <div class="cs-search-heading"><strong id="csBookingTitle">Reserve sua estadia</strong><small>Encontre a acomodação ideal para os seus dias de descanso.</small></div>
        <div class="cs-search-fields">
            <label class="cs-search-field"><span>CHECK-IN</span><input type="date" name="check_in" id="csCheckin" min="<?php echo e(now()->toDateString()); ?>" value="<?php echo e(now()->addDay()->toDateString()); ?>" required></label>
            <label class="cs-search-field"><span>CHECK-OUT</span><input type="date" name="check_out" id="csCheckout" min="<?php echo e(now()->addDay()->toDateString()); ?>" value="<?php echo e(now()->addDays(3)->toDateString()); ?>" required></label>
            <label class="cs-search-field cs-search-guest"><span>ADULTOS</span><select name="adults" aria-label="Número de adultos"><option value="1">1 adulto</option><option value="2" selected>2 adultos</option><option value="3">3 adultos</option><option value="4">4 adultos</option><option value="5">5 adultos</option><option value="6">6 adultos</option></select></label>
            <label class="cs-search-field cs-search-guest"><span>CRIANÇAS</span><select name="children" aria-label="Número de crianças"><option value="0" selected>0 crianças</option><option value="1">1 criança</option><option value="2">2 crianças</option><option value="3">3 crianças</option><option value="4">4 crianças</option></select></label>
            <button class="cs-booking-submit" type="submit"><span aria-hidden="true">⌕</span> Consultar disponibilidade</button>
        </div>
    </form>
</section>

<section class="cs-amenity-strip wrap" aria-label="Destaques da pousada">
    <div><span class="cs-amenity-icon">☕</span><strong>Café da manhã</strong><small>Momentos para saborear</small></div>
    <div><span class="cs-amenity-icon">◉</span><strong>Wi-Fi gratuito</strong><small>Conexão em todos os ambientes</small></div>
    <div><span class="cs-amenity-icon">▤</span><strong>Estacionamento</strong><small>Mais comodidade</small></div>
    <div><span class="cs-amenity-icon">≋</span><strong>Piscina & lazer</strong><small>Um convite ao descanso</small></div>
    <div><span class="cs-amenity-icon">❀</span><strong>Natureza</strong><small>Beleza em cada cenário</small></div>
</section>

<section class="cs-rooms-section wrap" id="acomodacoes" aria-labelledby="csRoomsTitle">
    <div class="cs-section-heading">
        <div><span class="cs-overline">ACOMODAÇÕES</span><h2 id="csRoomsTitle">Nossas <em>Acomodações</em></h2><p>Escolha seu refúgio. Cada ambiente foi pensado para transformar sua estadia.</p></div>
        <a class="cs-text-button" href="<?php echo e(route('rooms.index')); ?>">Ver todas as acomodações <span aria-hidden="true">→</span></a>
    </div>
    <div class="room-grid cs-featured-rooms">
        <?php $__empty_1 = true; $__currentLoopData = $types->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('partials.type-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="cs-empty"><strong>Acomodações em preparação.</strong><p>As unidades aparecerão aqui assim que forem cadastradas no painel.</p></div>
        <?php endif; ?>
    </div>
</section>

<section class="cs-experiences" aria-labelledby="csExperiencesTitle">
    <div class="wrap cs-experiences-inner">
        <div class="cs-experiences-copy"><span class="cs-overline cs-overline-light">EXPERIÊNCIAS</span><h2 id="csExperiencesTitle">Descubra experiências<br><em>inesquecíveis</em></h2><p>Sabores, paisagens e momentos que tornam sua viagem ainda mais especial.</p><a class="cs-experience-link" href="<?php echo e(route('page.show', 'experiencias')); ?>">Conheça as experiências <span aria-hidden="true">→</span></a></div>
        <div class="cs-experience-cards">
            <a href="<?php echo e(route('page.show', 'experiencias')); ?>"><img src="<?php echo e(asset('assets/photos/praia-e-pousada.webp')); ?>" loading="lazy" alt="Praia e natureza tropical ilustrativas"><strong>Praias & natureza</strong></a>
            <a href="<?php echo e(route('page.show', 'experiencias')); ?>"><img src="<?php echo e(asset('assets/photos/cafe-da-manha.webp')); ?>" loading="lazy" alt="Café da manhã tropical ilustrativo"><strong>Sabores locais</strong></a>
            <a href="<?php echo e(route('page.show', 'galeria')); ?>"><img src="<?php echo e(asset('assets/photos/piscina-iluminada.webp')); ?>" loading="lazy" alt="Piscina e lazer em pousada ilustrativa"><strong>Descanso & lazer</strong></a>
        </div>
    </div>
</section>

<section class="cs-about-section wrap" aria-labelledby="csAboutTitle">
    <div class="cs-about-visual"><img src="<?php echo e(asset('assets/photos/praia-e-pousada.webp')); ?>" alt="Jardins de pousada tropical e litoral, imagem ilustrativa" loading="lazy"><div class="cs-about-stamp">Seu momento<br><strong>de paz.</strong></div></div>
    <div class="cs-about-copy"><span class="cs-overline">BEM-VINDO À COSTA SERENA</span><h2 id="csAboutTitle">Um convite para<br><em>desacelerar.</em></h2><p>Entre a brisa do mar e o aconchego de cada ambiente, você encontra o equilíbrio entre tranquilidade e bem-estar.</p><p>Viva uma estadia especial, com atendimento acolhedor e momentos que merecem ser lembrados.</p><a class="cs-about-link" href="<?php echo e(route('page.show', 'sobre')); ?>">Conheça nossa história <span aria-hidden="true">↗</span></a></div>
</section>

<section class="cs-bottom-call"><div class="wrap"><span class="cs-overline cs-overline-light">SUA PRÓXIMA VIAGEM COMEÇA AQUI</span><h2>Seu descanso merece um lugar especial.</h2><a href="<?php echo e(route('rooms.index')); ?>" class="cs-booking-submit">Planejar minha estadia <span aria-hidden="true">→</span></a></div></section>
<p class="cs-photo-disclaimer wrap">As fotografias exibidas são ilustrativas, produzidas para a demonstração do sistema, e não retratam um estabelecimento real.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Estatísticas\Desktop\pousada-costa-serena\resources\views\home.blade.php ENDPATH**/ ?>