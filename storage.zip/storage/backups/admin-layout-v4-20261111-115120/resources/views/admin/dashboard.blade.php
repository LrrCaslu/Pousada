@extends('layouts.admin')
@section('title', 'Dashboard')
@section('content')
@php
    $icons = asset('assets/icons-admin.svg');
    $firstName = \Illuminate\Support\Str::before(auth()->user()->name, ' ');
    $greeting = now()->hour < 12 ? 'Bom dia' : (now()->hour < 18 ? 'Boa tarde' : 'Boa noite');
    $periodText = ['7d' => 'Últimos 7 dias', '30d' => 'Últimos 30 dias', '90d' => 'Últimos 90 dias', 'month' => 'Este mês', 'custom' => 'Período personalizado'][$period] ?? 'Últimos 30 dias';
    $statusStops = [];
    foreach ($statusGroups as $group) {
        if ($group['count'] > 0) {
            $statusStops[] = $group['color'].' '.$group['start'].'% '.$group['end'].'%';
        }
    }
    $statusGradient = count($statusStops) ? 'conic-gradient('.implode(', ', $statusStops).')' : 'conic-gradient(#e9eeeb 0% 100%)';
    $paymentStops = [];
    foreach ($paymentGroups as $group) {
        if ($group['amount'] > 0) {
            $paymentStops[] = $group['color'].' '.$group['start'].'% '.$group['end'].'%';
        }
    }
    $paymentGradient = count($paymentStops) ? 'conic-gradient('.implode(', ', $paymentStops).')' : 'conic-gradient(#e9eeeb 0% 100%)';
@endphp
<div class="ref-dashboard">
    <section class="ref-dashboard-heading">
        <div>
            <span class="ref-overline">Visão geral da pousada</span>
            <h1>Painel Administrativo</h1>
            <p class="ref-greeting">{{ $greeting }}, {{ $firstName }}! <span aria-hidden="true">👋</span></p>
            <p class="ref-subtitle">Aqui está o resumo da Pousada Costa Serena.</p>
        </div>
        <details class="ref-period-menu" id="refPeriodMenu">
            <summary><svg class="ref-icon"><use href="{{ $icons }}#calendar"></use></svg><span>Período: <strong>{{ $periodText }}</strong></span><svg class="ref-icon ref-chevron"><use href="{{ $icons }}#chevron-down"></use></svg></summary>
            <div class="ref-period-popover">
                <strong>Filtrar período</strong>
                <div class="ref-period-choices">
                    @foreach(['7d' => 'Últimos 7 dias', '30d' => 'Últimos 30 dias', '90d' => 'Últimos 90 dias', 'month' => 'Este mês'] as $key => $label)
                        <a href="{{ route('admin.dashboard', ['period' => $key]) }}" class="{{ $period === $key ? 'is-selected' : '' }}" @if($period === $key) aria-current="page" @endif>{{ $label }}</a>
                    @endforeach
                </div>
                <form method="GET" action="{{ route('admin.dashboard') }}" class="ref-custom-period">
                    <input type="hidden" name="period" value="custom">
                    <label>De<input type="date" name="start" value="{{ $startDate }}" max="{{ now()->toDateString() }}" required></label>
                    <label>Até<input type="date" name="end" value="{{ $endDate }}" max="{{ now()->toDateString() }}" required></label>
                    <button type="submit">Aplicar período</button>
                </form>
                <p>De {{ \Carbon\Carbon::parse($startDate)->format('d/m/Y') }} até {{ \Carbon\Carbon::parse($endDate)->format('d/m/Y') }}.</p>
            </div>
        </details>
    </section>

    <section class="ref-kpis" aria-label="Indicadores principais">
        <article class="ref-kpi ref-kpi-reservations">
            <span class="ref-kpi-icon"><svg class="ref-icon"><use href="{{ $icons }}#calendar-check"></use></svg></span>
            <span class="ref-kpi-name">Reservas</span>
            <strong class="ref-kpi-number">{{ number_format($reservationsCount, 0, ',', '.') }}</strong>
            <div class="ref-kpi-bottom">
                <small>Registradas no período</small>
                @if($previousReservations > 0)
                    @php
                        $reservationVariation = ($reservationsCount - $previousReservations) * 100 / $previousReservations;
                    @endphp
                    <span class="ref-kpi-change {{ $reservationVariation < 0 ? 'is-negative' : '' }}">{{ $reservationVariation < 0 ? '↘' : '↗' }} {{ number_format(abs($reservationVariation), 1, ',', '.') }}%</span>
                @else
                    <span class="ref-kpi-chip">Dados reais</span>
                @endif
            </div>
        </article>
        <article class="ref-kpi ref-kpi-occupancy">
            <span class="ref-kpi-icon"><svg class="ref-icon"><use href="{{ $icons }}#bed"></use></svg></span>
            <span class="ref-kpi-name">Ocupação Média</span>
            <strong class="ref-kpi-number">{{ number_format($occupancyAverage, 1, ',', '.') }}%</strong>
            <div class="ref-kpi-bottom"><small>No período escolhido</small><span class="ref-kpi-chip">{{ $totalRooms }} quartos</span></div>
        </article>
        <article class="ref-kpi ref-kpi-guests">
            <span class="ref-kpi-icon"><svg class="ref-icon"><use href="{{ $icons }}#users"></use></svg></span>
            <span class="ref-kpi-name">Hóspedes</span>
            <strong class="ref-kpi-number">{{ number_format($totalGuests, 0, ',', '.') }}</strong>
            <div class="ref-kpi-bottom"><small>Total cadastrado</small><span class="ref-kpi-chip">+{{ $newGuests }} no período</span></div>
        </article>
        <article class="ref-kpi ref-kpi-revenue">
            <span class="ref-kpi-icon"><svg class="ref-icon"><use href="{{ $icons }}#dollar"></use></svg></span>
            @if($canFinance)
                <span class="ref-kpi-name">Receita (período)</span>
                <strong class="ref-kpi-number ref-currency">R$ {{ number_format($received, 2, ',', '.') }}</strong>
                <div class="ref-kpi-bottom"><small>Recebimentos no período</small>
                    @if($previousReceived > 0)
                        @php
                            $receivedVariation = ($received - $previousReceived) * 100 / $previousReceived;
                        @endphp
                        <span class="ref-kpi-change {{ $receivedVariation < 0 ? 'is-negative' : '' }}">{{ $receivedVariation < 0 ? '↘' : '↗' }} {{ number_format(abs($receivedVariation), 1, ',', '.') }}%</span>
                    @else
                        <span class="ref-kpi-chip">Simulado</span>
                    @endif
                </div>
            @else
                <span class="ref-kpi-name">Check-ins hoje</span>
                <strong class="ref-kpi-number">{{ $arrivalToday }}</strong>
                <div class="ref-kpi-bottom"><small>Chegadas previstas</small><span class="ref-kpi-chip">Hoje</span></div>
            @endif
        </article>
    </section>

    <div class="ref-dashboard-grid ref-top-analytics">
        <section class="ref-panel ref-occupancy-panel">
            <div class="ref-panel-heading"><h2>Evolução da Ocupação</h2><span class="ref-panel-actions" aria-hidden="true"><svg class="ref-icon"><use href="{{ $icons }}#more"></use></svg></span></div>
            <div class="ref-chart-legend"><span><i class="ref-dot ref-dot-green"></i> Ocupação (%)</span><span><i class="ref-dot ref-dot-mint"></i> Diárias ocupadas</span></div>
            <div class="ref-svg-chart" data-ref-chart="occupancy" role="img" aria-label="Evolução da ocupação e dos quartos ocupados no período selecionado"><span class="ref-chart-placeholder">Preparando gráfico...</span></div>
        </section>
        <section class="ref-panel ref-status-panel">
            <div class="ref-panel-heading"><h2>Status das Reservas</h2><span class="ref-panel-actions" aria-hidden="true"><svg class="ref-icon"><use href="{{ $icons }}#more"></use></svg></span></div>
            <div class="ref-donut-layout">
                <div class="ref-donut cs-status-donut" style="background:{{ $statusGradient }}" role="img" aria-label="Distribuição de {{ $reservationsCount }} reservas por status"><div class="ref-donut-hole"><strong>{{ $reservationsCount }}</strong><small>Reservas</small></div></div>
                <div class="ref-donut-legend">
                    @foreach($statusGroups as $group)
                        <div><span><i style="background:{{ $group['color'] }}"></i>{{ $group['name'] }}</span><strong>{{ number_format($group['percentage'], 1, ',', '.') }}% <small>({{ $group['count'] }})</small></strong></div>
                    @endforeach
                </div>
            </div>
        </section>
    </div>

    <div class="ref-dashboard-grid ref-mid-analytics">
        <section class="ref-panel ref-arrivals-panel">
            <div class="ref-panel-heading"><h2>Próximas Chegadas <small>(Check-in)</small></h2><a href="{{ route('admin.calendar') }}">Ver todas <svg class="ref-icon"><use href="{{ $icons }}#arrow-right"></use></svg></a></div>
            <div class="ref-arrivals-list">
                @if($canReservations)
                    @forelse($upcoming->take(4) as $booking)
                        <div class="ref-arrival">
                            <span class="ref-guest-avatar">{{ mb_strtoupper(mb_substr($booking->guest?->name ?? 'H', 0, 1)) }}{{ mb_strtoupper(mb_substr(\Illuminate\Support\Str::after($booking->guest?->name ?? ' ', ' '), 0, 1)) }}</span>
                            <span class="ref-arrival-info"><strong>{{ $booking->guest?->name ?? 'Hóspede' }}</strong><small>{{ $booking->check_in->isToday() ? 'Hoje' : $booking->check_in->format('d/m') }} · {{ $booking->rooms->pluck('number')->join(', ') ?: 'Acomodação' }}</small></span>
                            <a class="ref-chip ref-chip-success" href="{{ route('admin.reservations.show', $booking) }}">{{ $booking->status === 'checkin' ? 'Hospedado' : 'Confirmada' }}</a>
                        </div>
                    @empty
                        <div class="ref-empty">Não há chegadas confirmadas para os próximos dias.</div>
                    @endforelse
                @else
                    <div class="ref-empty">Agenda de hóspedes disponível para a recepção.</div>
                @endif
            </div>
        </section>
        <section class="ref-panel ref-rooms-panel">
            <div class="ref-panel-heading"><h2>Acomodações</h2><span class="ref-panel-actions" aria-hidden="true"><svg class="ref-icon"><use href="{{ $icons }}#more"></use></svg></span></div>
            <p class="ref-panel-meta">{{ $totalRooms }} quartos ativos</p>
            <div class="ref-room-states">
                <div><strong class="ref-state-num ref-state-available">{{ $availableToday }}</strong><span>Disponíveis</span><svg class="ref-icon"><use href="{{ $icons }}#bed"></use></svg></div>
                <div><strong class="ref-state-num ref-state-occupied">{{ $occupiedToday }}</strong><span>Ocupados</span></div>
                <div><strong class="ref-state-num ref-state-maintenance">{{ $blockedToday }}</strong><span>Em manutenção / bloqueio</span></div>
            </div>
            @can('manage-rooms')<a href="{{ route('admin.rooms.index') }}" class="ref-card-footer-link">Gerenciar acomodações <svg class="ref-icon"><use href="{{ $icons }}#arrow-right"></use></svg></a>@endcan
        </section>
        <section class="ref-panel ref-payment-panel">
            @if($canFinance)
                <div class="ref-panel-heading"><h2>Recebimentos por Método</h2><span class="ref-panel-actions" aria-hidden="true"><svg class="ref-icon"><use href="{{ $icons }}#more"></use></svg></span></div>
                <div class="ref-donut-layout ref-small-donut-layout">
                    <div class="ref-donut ref-small-donut" style="background:{{ $paymentGradient }}" role="img" aria-label="Distribuição dos pagamentos aprovados por método"><div class="ref-donut-hole"><strong>R$ {{ number_format($received, 0, ',', '.') }}</strong><small>Recebidos</small></div></div>
                    <div class="ref-donut-legend">
                        @forelse($paymentGroups as $group)
                            <div><span><i style="background:{{ $group['color'] }}"></i>{{ $group['name'] }}</span><strong>{{ number_format($group['percentage'], 1, ',', '.') }}%</strong></div>
                        @empty
                            <div class="ref-empty">Sem recebimentos no período.</div>
                        @endforelse
                    </div>
                </div>
            @else
                <div class="ref-panel-heading"><h2>Operação de Hoje</h2></div>
                <div class="ref-today-operations"><div><svg class="ref-icon"><use href="{{ $icons }}#calendar-check"></use></svg><span>Check-ins previstos</span><strong>{{ $arrivalToday }}</strong></div><div><svg class="ref-icon"><use href="{{ $icons }}#calendar"></use></svg><span>Check-outs previstos</span><strong>{{ $departureToday }}</strong></div><div><svg class="ref-icon"><use href="{{ $icons }}#clock"></use></svg><span>Reservas pendentes</span><strong>{{ $pending }}</strong></div></div>
            @endif
        </section>
    </div>

    <div class="ref-dashboard-grid ref-bottom-analytics">
        <section class="ref-panel ref-monthly-panel">
            <div class="ref-panel-heading"><h2>{{ $monthlyChartTitle }}</h2><span class="ref-panel-actions" aria-hidden="true"><svg class="ref-icon"><use href="{{ $icons }}#more"></use></svg></span></div>
            <div class="ref-svg-chart ref-monthly-chart" data-ref-chart="monthly" role="img" aria-label="{{ $monthlyChartTitle }} calculada a partir do banco de dados"><span class="ref-chart-placeholder">Preparando gráfico...</span></div>
            @if($canFinance)<small class="ref-hint">Pagamentos aprovados no modo de demonstração, não transações bancárias reais.</small>@endif
        </section>
        <section class="ref-panel ref-roomrates-panel">
            <div class="ref-panel-heading"><h2>Taxa de Ocupação por Acomodação</h2><span class="ref-panel-actions" aria-hidden="true"><svg class="ref-icon"><use href="{{ $icons }}#more"></use></svg></span></div>
            <div class="ref-roomrate-list">
                @forelse($roomOccupancy as $type)
                    <div class="ref-roomrate-row"><span title="{{ $type['name'] }}">{{ $type['name'] }}</span><div class="ref-roomrate-track"><span style="width:{{ $type['percentage'] }}%"></span></div><strong>{{ number_format($type['percentage'], 1, ',', '.') }}%</strong></div>
                @empty
                    <div class="ref-empty">Cadastre quartos para visualizar a ocupação por categoria.</div>
                @endforelse
            </div>
        </section>
    </div>

    <section class="ref-actions-footer" aria-label="Ações rápidas">
        <span>Atalhos</span>
        @can('manage-reservations')<a href="{{ route('admin.reservations.create') }}"><svg class="ref-icon"><use href="{{ $icons }}#plus"></use></svg> Nova reserva</a>@endcan
        <a href="{{ route('admin.calendar') }}"><svg class="ref-icon"><use href="{{ $icons }}#calendar"></use></svg> Calendário</a>
        @can('manage-settings')<a href="{{ route('admin.pages.index') }}"><svg class="ref-icon"><use href="{{ $icons }}#layer"></use></svg> Editar páginas</a>@endcan
        <button type="button" id="biExportCsv"><svg class="ref-icon"><use href="{{ $icons }}#upload"></use></svg> Exportar indicadores CSV</button>
    </section>
    <p class="ref-data-footnote">Indicadores consultados no banco MySQL. Reservas por data de criação; ocupação por noites; disponibilidade atual considera os bloqueios cadastrados. A apresentação se adapta às permissões do usuário.</p>
</div>
<script type="application/json" id="bi-dashboard-data">@json($chartData)</script>
@endsection
