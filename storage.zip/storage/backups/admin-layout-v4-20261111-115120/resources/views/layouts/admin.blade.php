<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#064435">
    <title>@yield('title', 'Painel administrativo') · Pousada Costa Serena</title>
    @if(file_exists(public_path('build/manifest.json')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @else
        <link rel="stylesheet" href="{{ asset('assets/app.css') }}">
        <script src="{{ asset('assets/app.js') }}" defer></script>
    @endif
    <link rel="stylesheet" href="{{ asset('assets/admin-studio.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/costa-admin-v3.css') }}?v=3.1">
    <link rel="stylesheet" href="{{ asset('assets/admin-reference-v4.css') }}?v=4.0.0">
    <script src="{{ asset('assets/admin-studio.js') }}" defer></script>
    <script src="{{ asset('assets/costa-admin-v3.js') }}?v=3.1" defer></script>
    <script src="{{ asset('assets/admin-reference-v4.js') }}?v=4.0.0" defer></script>
</head>
<body class="admin-body cs-admin-body cs-ref-body">
@php
    $adminIcons = asset('assets/icons-admin.svg');
    $firstName = \Illuminate\Support\Str::before(auth()->user()->name, ' ');
@endphp
<div class="app-shell cs-app-shell ref-shell">
    <aside class="sidebar cs-sidebar ref-sidebar" id="csAdminSidebar" aria-label="Navegação administrativa">
        <div class="ref-sidebar-content">
            <a class="brand inverse ref-logo" href="{{ route('admin.dashboard') }}" aria-label="Pousada Costa Serena — Painel administrativo">
                <img src="{{ asset('assets/brand-admin.svg') }}" width="62" height="50" alt="">
                <span>Pousada<strong>Costa Serena</strong></span>
            </a>
            <nav class="ref-navigation" aria-label="Módulos da pousada">
                <a class="{{ request()->routeIs('admin.dashboard') ? 'is-active' : '' }}" href="{{ route('admin.dashboard') }}" @if(request()->routeIs('admin.dashboard')) aria-current="page" @endif>
                    <svg class="ref-icon"><use href="{{ $adminIcons }}#home"></use></svg><span>Dashboard</span>
                </a>
                @can('manage-reservations')
                    <a class="{{ request()->routeIs('admin.reservations.*') ? 'is-active' : '' }}" href="{{ route('admin.reservations.index') }}">
                        <svg class="ref-icon"><use href="{{ $adminIcons }}#calendar-check"></use></svg><span>Reservas</span>
                        @if(isset($pending) && $pending > 0)
                            <span class="ref-nav-count">{{ $pending }}</span>
                        @endif
                    </a>
                @endcan
                <a class="{{ request()->routeIs('admin.calendar*') ? 'is-active' : '' }}" href="{{ route('admin.calendar') }}">
                    <svg class="ref-icon"><use href="{{ $adminIcons }}#calendar"></use></svg><span>Calendário</span>
                </a>
                @can('manage-rooms')
                    <a class="{{ request()->routeIs('admin.rooms.*') ? 'is-active' : '' }}" href="{{ route('admin.rooms.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#bed"></use></svg><span>Acomodações</span></a>
                @endcan
                @can('manage-reservations')
                    <a class="{{ request()->routeIs('admin.guests.*') ? 'is-active' : '' }}" href="{{ route('admin.guests.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#users"></use></svg><span>Hóspedes</span></a>
                @endcan
                @can('manage-finance')
                    <a class="{{ request()->routeIs('admin.finance.*') ? 'is-active' : '' }}" href="{{ route('admin.finance.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#dollar"></use></svg><span>Financeiro</span><svg class="ref-icon ref-nav-chevron"><use href="{{ $adminIcons }}#chevron-down"></use></svg></a>
                @endcan
                @can('manage-settings')
                    <a class="{{ request()->routeIs('admin.rates.*') ? 'is-active' : '' }}" href="{{ route('admin.rates.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#price-tag"></use></svg><span>Tarifas e Promoções</span></a>
                    <a class="{{ request()->routeIs('admin.pages.*') ? 'is-active' : '' }}" href="{{ route('admin.pages.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#layer"></use></svg><span>Páginas do Site</span></a>
                    <a class="{{ request()->routeIs('admin.media.*') ? 'is-active' : '' }}" href="{{ route('admin.media.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#images"></use></svg><span>Conteúdo e Mídias</span></a>
                @endcan
                @can('manage-housekeeping')
                    <a class="{{ request()->routeIs('admin.housekeeping.*') ? 'is-active' : '' }}" href="{{ route('admin.housekeeping.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#broom"></use></svg><span>Governança</span><svg class="ref-icon ref-nav-chevron"><use href="{{ $adminIcons }}#chevron-down"></use></svg></a>
                @endcan
                @can('manage-settings')
                    <a class="{{ request()->routeIs('admin.staff.*') ? 'is-active' : '' }}" href="{{ route('admin.staff.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#user-cog"></use></svg><span>Funcionários</span></a>
                @endcan
                @can('manage-finance')
                    <a class="{{ request()->routeIs('admin.reports') ? 'is-active' : '' }}" href="{{ route('admin.reports') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#chart"></use></svg><span>Relatórios</span></a>
                @endcan
                @can('manage-settings')
                    <a class="{{ request()->routeIs('admin.settings.*') ? 'is-active' : '' }}" href="{{ route('admin.settings.index') }}"><svg class="ref-icon"><use href="{{ $adminIcons }}#settings"></use></svg><span>Configurações</span></a>
                @endcan
            </nav>
            <div class="ref-sidebar-footer">
                <a href="{{ route('home') }}" target="_blank" rel="noopener noreferrer"><svg class="ref-icon"><use href="{{ $adminIcons }}#external"></use></svg> Ver site público</a>
                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button type="submit"><svg class="ref-icon"><use href="{{ $adminIcons }}#logout"></use></svg> Sair da conta</button>
                </form>
            </div>
        </div>
    </aside>
    <div class="admin-main cs-admin-main ref-main">
        <header class="admin-top cs-admin-top ref-topbar">
            <button type="button" id="navToggle" class="mobile-toggle ref-mobile-toggle" aria-controls="csAdminSidebar" aria-expanded="false" aria-label="Abrir menu administrativo"><svg class="ref-icon"><use href="{{ $adminIcons }}#menu"></use></svg></button>
            <div class="ref-top-spacer"></div>
            <div class="admin-command cs-command ref-search">
                <button type="button" id="adminCommandToggle" class="admin-command-toggle" aria-controls="adminCommandPanel" aria-expanded="false" aria-label="Pesquisar módulos"><svg class="ref-icon"><use href="{{ $adminIcons }}#search"></use></svg><span>Buscar no sistema...</span><kbd>Ctrl K</kbd></button>
                <div id="adminCommandPanel" class="admin-command-panel" hidden>
                    <label class="admin-command-field">Buscar módulo<input id="adminCommandInput" type="search" autocomplete="off" placeholder="Reservas, páginas, financeiro..."></label>
                    <nav id="adminCommandLinks" aria-label="Resultados da pesquisa">
                        <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                        <a href="{{ route('admin.calendar') }}">Calendário</a>
                        @can('manage-reservations')
                            <a href="{{ route('admin.reservations.index') }}">Reservas</a><a href="{{ route('admin.guests.index') }}">Hóspedes</a>
                        @endcan
                        @can('manage-rooms')<a href="{{ route('admin.rooms.index') }}">Acomodações</a>@endcan
                        @can('manage-finance')<a href="{{ route('admin.finance.index') }}">Financeiro</a><a href="{{ route('admin.reports') }}">Relatórios</a>@endcan
                        @can('manage-housekeeping')<a href="{{ route('admin.housekeeping.index') }}">Governança</a>@endcan
                        @can('manage-settings')
                            <a href="{{ route('admin.rates.index') }}">Tarifas</a><a href="{{ route('admin.pages.index') }}">Páginas do site</a><a href="{{ route('admin.media.index') }}">Imagens do site</a><a href="{{ route('admin.staff.index') }}">Funcionários</a><a href="{{ route('admin.settings.index') }}">Configurações</a>
                        @endcan
                    </nav>
                    <p id="adminCommandEmpty" hidden>Nenhum módulo encontrado.</p>
                </div>
            </div>
            @can('manage-reservations')
                <a class="ref-top-circle ref-alert-link" href="{{ route('admin.reservations.index') }}" aria-label="Consultar reservas pendentes" title="Reservas"><svg class="ref-icon"><use href="{{ $adminIcons }}#bell"></use></svg>@if(isset($pending) && $pending > 0)<i class="ref-alert-dot"></i>@endif</a>
            @endcan
            <details class="ref-top-details ref-help-box">
                <summary class="ref-top-circle" title="Ajuda" aria-label="Ajuda"><svg class="ref-icon"><use href="{{ $adminIcons }}#help"></use></svg></summary>
                <div class="ref-top-popover"><strong>Ajuda rápida</strong><p>Use o menu lateral para gerenciar a pousada. Pressione <kbd>Ctrl K</kbd> para localizar módulos.</p><a href="{{ route('home') }}" target="_blank" rel="noopener noreferrer">Abrir o site público</a></div>
            </details>
            <details class="ref-top-details ref-profile-box">
                <summary class="ref-profile" aria-label="Abrir menu do usuário"><span class="ref-profile-avatar">{{ mb_strtoupper(mb_substr($firstName, 0, 1)) }}</span><span class="ref-profile-names"><strong>{{ $firstName }}</strong><small>{{ auth()->user()->role?->name ?? 'Equipe' }}</small></span><svg class="ref-icon ref-profile-chevron"><use href="{{ $adminIcons }}#chevron-down"></use></svg></summary>
                <div class="ref-top-popover ref-profile-popover">
                    <strong>{{ auth()->user()->name }}</strong><small>{{ auth()->user()->email }}</small>
                    @can('manage-settings')<a href="{{ route('admin.settings.index') }}">Configurações da pousada</a>@endcan
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit">Sair da conta</button>
                    </form>
                </div>
            </details>
        </header>
        <main class="admin-content cs-admin-content ref-content" id="refMainContent">
            @if(session('success'))
                <div class="alert success" role="status">{{ session('success') }}</div>
            @endif
            @if($errors->any())
                <div class="alert error" role="alert"><strong>Revise os dados:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
            @endif
            @yield('content')
        </main>
    </div>
</div>
</body>
</html>
