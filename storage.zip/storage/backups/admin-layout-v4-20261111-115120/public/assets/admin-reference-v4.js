/** Pousada Costa Serena V4 — gráficos SVG com dados reais entregues pelo Laravel.
 * Sem CDN ou dependências externas. O JavaScript não altera métricas financeiras. */
(() => {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const br = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 });
  const chartSource = document.getElementById('bi-dashboard-data');

  function create(tag, attributes = {}, text) {
    const item = document.createElementNS(NS, tag);
    Object.entries(attributes).forEach(([key, value]) => item.setAttribute(key, String(value)));
    if (text !== undefined) item.textContent = String(text);
    return item;
  }
  function textNode(svg, label, x, y, options = {}) {
    const node = create('text', {
      x, y, fill: options.color || '#708178', 'font-size': options.size || 11,
      'font-family': "Inter, 'Segoe UI', Arial, sans-serif",
      'text-anchor': options.anchor || 'start', 'font-weight': options.weight || 550
    }, label);
    svg.append(node);
    return node;
  }
  const safe = value => Math.max(0, Number.isFinite(Number(value)) ? Number(value) : 0);

  function drawOccupancy(container, data) {
    const labels = Array.isArray(data.labels) ? data.labels : [];
    const occupancy = Array.isArray(data.occupancy) ? data.occupancy.map(safe) : [];
    const rooms = Array.isArray(data.occupiedRooms) ? data.occupiedRooms.map(safe) : [];
    if (!labels.length || labels.length !== occupancy.length || labels.length !== rooms.length) return noData(container);

    const width = 700, height = 250, left = 48, right = 32, top = 13, bottom = 31;
    const plotWidth = width - left - right, plotHeight = height - top - bottom;
    const maxRooms = Math.max(1, ...rooms);
    const atX = index => left + (index + .5) * plotWidth / labels.length;
    const atY = percentage => top + plotHeight * (1 - Math.min(100, percentage) / 100);
    const barW = Math.min(20, Math.max(2.1, plotWidth / labels.length * .62));
    const svg = create('svg', { viewBox: `0 0 ${width} ${height}`, preserveAspectRatio: 'none', role: 'presentation', focusable: 'false' });
    const defs = create('defs');
    const gradient = create('linearGradient', { id: 'refOccupancyArea', x1: '0', x2: '0', y1: '0', y2: '1' });
    gradient.append(create('stop', { offset: '0%', 'stop-color': '#168b5e', 'stop-opacity': '.16' }));
    gradient.append(create('stop', { offset: '100%', 'stop-color': '#168b5e', 'stop-opacity': '.02' }));
    defs.append(gradient); svg.append(defs);

    for (let i = 0; i <= 4; i++) {
      const tick = i * 25, y = atY(tick);
      svg.append(create('line', { x1: left, x2: width - right, y1: y, y2: y, stroke: '#e8eee9', 'stroke-width': 1 }));
      textNode(svg, `${tick}%`, left - 9, y + 4, { anchor: 'end', size: 11, color: '#6f7974' });
      textNode(svg, br.format(Math.round(maxRooms * tick / 100)), width - 9, y + 4, { anchor: 'end', size: 10, color: '#84968d' });
    }

    rooms.forEach((value, index) => {
      const h = plotHeight * value / maxRooms;
      const rect = create('rect', { x: atX(index) - barW / 2, y: top + plotHeight - h, width: barW,
        height: Math.max(0, h), rx: 1.6, fill: '#a5dfbb', opacity: '.84' });
      rect.append(create('title', {}, `${labels[index]}: ${br.format(value)} ${value === 1 ? 'quarto ocupado' : 'quartos ocupados'}`));
      svg.append(rect);
    });
    const path = occupancy.map((value, index) => `${atX(index)} ${atY(value)}`).join(' L ');
    svg.append(create('path', { d: `M ${atX(0)} ${atY(0)} L ${path} L ${atX(labels.length-1)} ${atY(0)} Z`, fill: 'url(#refOccupancyArea)' }));
    svg.append(create('path', { d: 'M ' + path, fill: 'none', stroke: '#047e4c', 'stroke-width': 3.2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
    const everyPoint = Math.max(1, Math.ceil(labels.length / 23));
    occupancy.forEach((value, index) => {
      if (index % everyPoint && index !== occupancy.length - 1) return;
      const circle = create('circle', { cx: atX(index), cy: atY(value), r: 3.5, fill: '#fff', stroke: '#057d4f', 'stroke-width': 2.5 });
      circle.append(create('title', {}, `${labels[index]}: ${br.format(value)}% de ocupação`));
      svg.append(circle);
    });
    const ticks = Math.max(1, Math.ceil(labels.length / 7));
    labels.forEach((label, index) => {
      if (index % ticks !== 0 && index !== labels.length - 1) return;
      textNode(svg, label, atX(index), height - 10, { size: 10, anchor: 'middle', color: '#67766b' });
    });
    container.replaceChildren(svg);
  }

  function drawMonthly(container, data) {
    const labels = Array.isArray(data.monthlyLabels) ? data.monthlyLabels : [];
    const values = Array.isArray(data.monthlyValues) ? data.monthlyValues.map(safe) : [];
    if (!labels.length || labels.length !== values.length) return noData(container);
    const width = 700, height = 245, left = 69, right = 14, top = 14, bottom = 31;
    const plotWidth = width - left - right, plotHeight = height - top - bottom;
    const maxValue = Math.max(1, ...values) * 1.08;
    const svg = create('svg', { viewBox: `0 0 ${width} ${height}`, preserveAspectRatio: 'none', role: 'presentation', focusable: 'false' });
    const money = document.querySelector('.ref-kpi-revenue .ref-currency') !== null;
    const fmt = value => money ? 'R$ ' + (value >= 1000 ? br.format(value/1000) + ' mil' : br.format(value)) : br.format(value);
    for (let step = 0; step <= 4; step++) {
      const value = maxValue * step / 4;
      const y = top + plotHeight * (1 - step / 4);
      svg.append(create('line', {x1:left,x2:width-right,y1:y,y2:y,stroke:'#e8ece9','stroke-width':1}));
      textNode(svg,fmt(value),left-11,y+4,{anchor:'end',size:10,color:'#536b5d'});
    }
    const gap = plotWidth / labels.length;
    const barW = Math.min(62, gap * .64);
    values.forEach((value,index) => {
      const heightBar = plotHeight * value / maxValue;
      const x = left + gap * index + (gap-barW)/2;
      const y = top + plotHeight - heightBar;
      const bar = create('rect',{x,y,width:barW,height:Math.max(0,heightBar),rx:2,fill:index===values.length-1?'#066d47':'#70c69a'});
      bar.append(create('title',{}, `${labels[index]}: ${fmt(value)}`));
      svg.append(bar);
      textNode(svg,labels[index],left+gap*index+gap/2,height-11,{anchor:'middle',size:11,color:'#627669'});
    });
    container.replaceChildren(svg);
  }
  function noData(container) {
    const fallback = document.createElement('p');
    fallback.className = 'ref-chart-placeholder';
    fallback.textContent = 'Sem dados disponíveis para este gráfico.';
    container.replaceChildren(fallback);
  }
  if (chartSource) {
    try {
      const chartData = JSON.parse(chartSource.textContent);
      document.querySelectorAll('[data-ref-chart="occupancy"]').forEach(element => drawOccupancy(element, chartData));
      document.querySelectorAll('[data-ref-chart="monthly"]').forEach(element => drawMonthly(element, chartData));
    } catch (error) {
      document.querySelectorAll('[data-ref-chart]').forEach(noData);
      console.error('Não foi possível renderizar os gráficos administrativos.', error);
    }
  }

  // Dropdowns acessiveis com <details>: clique fora e Escape fecham o painel.
  const menus = Array.from(document.querySelectorAll('.ref-top-details, .ref-period-menu'));
  document.addEventListener('click', event => {
    menus.forEach(menu => {
      if (menu.open && !menu.contains(event.target)) menu.open = false;
    });
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') menus.forEach(menu => { menu.open = false; });
  });
})();
