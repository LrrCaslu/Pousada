@extends('layouts.admin')
@section('title', 'Relatórios')
@section('content')
<div class="bi-heading"><div><span class="bi-eyebrow">INTELIGÊNCIA FINANCEIRA / RELATÓRIOS</span><h1>Relatórios <span>gerenciais</span></h1><p>Indicadores apurados diretamente dos registros do MySQL.</p></div><a class="bi-button bi-button-outline" href="{{ route('admin.finance.index') }}">↗ Abrir financeiro</a></div>
<section class="bi-panel">
<form method="GET" class="filter-bar cs-reports-filter" action="{{ route('admin.reports') }}">
    <label>Início<input type="date" name="start" value="{{ $start }}" required></label>
    <label>Fim<input type="date" name="end" value="{{ $end }}" required></label>
    <button type="submit" class="btn-primary">Atualizar relatório</button>
</form>
</section>
<div class="stat-grid cs-reports-kpis">
    <article class="stat"><span>RESERVAS DO PERÍODO</span><strong>{{ number_format($report['reservas'], 0, ',', '.') }}</strong></article>
    <article class="stat"><span>CONFIRMADAS / CONCLUÍDAS</span><strong>{{ number_format($report['confirmadas'], 0, ',', '.') }}</strong></article>
    <article class="stat"><span>RECEBIDO</span><strong>R$ {{ number_format((float) $report['recebido'], 2, ',', '.') }}</strong></article>
    <article class="stat"><span>DESPESAS</span><strong>R$ {{ number_format((float) $report['despesas'], 2, ',', '.') }}</strong></article>
</div>
@php
    $maximum = max(1.0, (float) $report['recebido'], (float) $report['despesas']);
    $receivedPct = round(100 * (float) $report['recebido'] / $maximum, 2);
    $expensePct = round(100 * (float) $report['despesas'] / $maximum, 2);
@endphp
<section class="bi-panel cs-reports-chart"><div class="bi-panel-head"><div><span class="bi-eyebrow">RESULTADO OPERACIONAL</span><h2>Receitas e despesas</h2><p>Comparativo do período selecionado (pagamentos simulados e despesas cadastradas).</p></div></div>
    <div class="cs-report-bars">
        <div><div class="cs-report-bar-label"><strong>Recebimentos</strong><span>R$ {{ number_format((float) $report['recebido'], 2, ',', '.') }}</span></div><div class="cs-report-track"><span class="cs-report-received" style="width:{{ $receivedPct }}%"></span></div></div>
        <div><div class="cs-report-bar-label"><strong>Despesas</strong><span>R$ {{ number_format((float) $report['despesas'], 2, ',', '.') }}</span></div><div class="cs-report-track"><span class="cs-report-expenses" style="width:{{ $expensePct }}%"></span></div></div>
    </div>
    <p class="bi-fineprint">Os recebimentos são provenientes de pagamentos aprovados no modo simulado. Não representam transferências bancárias reais.</p>
</section>
@endsection
