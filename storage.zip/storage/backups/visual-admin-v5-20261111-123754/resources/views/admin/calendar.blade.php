@extends('layouts.admin')
@section('title','Calendário de ocupação')
@section('content')
<div class="bi-heading cs-calendar-heading">
    <div><span class="bi-eyebrow">GESTÃO DE HOSPEDAGENS / OCUPAÇÃO</span><h1>Calendário <span>de ocupação</span></h1><p>Visualize as estadias por dia, consulte disponibilidade e acompanhe as chegadas.</p></div>
    @can('manage-reservations')<a class="bi-button bi-button-dark" href="{{ route('admin.reservations.create') }}">＋ Nova reserva</a>@endcan
</div>
<div class="cs-calendar-layout">
  <section class="cs-calendar-card" aria-label="Calendário mensal">
    <div class="cs-calendar-toolbar"><div class="cs-calendar-nav"><button type="button" id="csCalPrev" aria-label="Mês anterior">‹</button><button type="button" id="csCalToday">Hoje</button><button type="button" id="csCalNext" aria-label="Próximo mês">›</button></div><h2 id="csCalTitle" aria-live="polite">Carregando calendário...</h2><label class="cs-calendar-filter">Quarto <select id="csCalRoom"><option value="">Todos os quartos</option>@foreach($rooms as $room)<option value="{{ $room->number }}">Quarto {{ $room->number }} — {{ $room->type?->name }}</option>@endforeach</select></label></div>
    <div class="cs-calendar-weekdays" aria-hidden="true"><span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span><span>Dom</span></div>
    <div id="reservation-calendar" class="cs-calendar-grid" data-url="{{ route('admin.calendar.events') }}" role="grid" aria-label="Dias do mês"><p class="cs-calendar-loading">Carregando reservas do banco de dados...</p></div>
    <div class="cs-calendar-legend"><span><i class="cs-color-confirmed"></i> Confirmada</span><span><i class="cs-color-checkin"></i> Em hospedagem</span><span><i class="cs-color-pending"></i> Pendente</span><span><i class="cs-color-other"></i> Outros estados</span></div>
  </section>
  <aside class="cs-calendar-aside" aria-live="polite"><span class="bi-eyebrow">PROGRAMAÇÃO DO DIA</span><h2 id="csCalSelectedTitle">Selecione uma data</h2><div id="csCalDayEvents"><p>Escolha um dia no calendário para consultar as reservas.</p></div><a class="cs-calendar-action" href="{{ route('admin.dashboard') }}">↗ Voltar ao dashboard</a></aside>
</div>
@endsection
