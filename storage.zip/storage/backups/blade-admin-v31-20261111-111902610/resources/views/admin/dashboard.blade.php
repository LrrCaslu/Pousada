@extends('layouts.admin')
@section('title', 'Visão geral')
@section('content')
<div class="bi-dashboard">
    <div class="bi-heading">
        <div>
            <div class="bi-eyebrow"><span class="bi-pulse"></span> INTELIGÊNCIA OPERACIONAL <span class="bi-separator">/</span> PAINEL AO VIVO</div>
            <h1>Visão geral <span>da pousada</span></h1>
            <p>Indicadores reais de reservas e ocupação, atualizados a cada consulta.</p>
        </div>
        <div class="bi-heading-actions">
            <span class="bi-sync"><span class="bi-sync-dot"></span> Dados do MySQL</span><button type="button" class="bi-button bi-button-outline" id="biExportCsv" title="Exportar os dados do período selecionado">↓ Exportar CSV</button>
            @can('manage-finance')
                <a href="{{ route('admin.reports') }}" class="bi-button bi-button-outline">↗ Ver relatórios</a>
            @endcan
        </div>
    </div>

    <div class="bi-quick-bar"><div><span class="bi-eyebrow">ACESSO RÁPIDO</span><strong>O que você precisa fazer?</strong></div>@if($canReservations)<a href="{{ route('admin.reservations.create') }}">＋ Nova reserva</a>@endif<a href="{{ route('admin.calendar') }}">▤ Calendário</a>@can('manage-rooms')<a href="{{ route('admin.rooms.index') }}">⌂ Acomodações</a>@endcan @can('manage-settings')<a href="{{ route('admin.pages.index') }}">✎ Editar páginas</a><a href="{{ route('admin.media.index') }}">▧ Imagens do site</a>@endcan</div>
    <section class="bi-filter" aria-label="Filtrar período de análise">
        <div class="bi-filter-intro">
            <span class="bi-filter-icon">◷</span>
            <div><strong>Período de análise</strong><small>{{ \Carbon\Carbon::parse($startDate)->format('d/m/Y') }} — {{ \Carbon\Carbon::parse($endDate)->format('d/m/Y') }} · {{ $dayCount }} {{ $dayCount === 1 ? 'dia' : 'dias' }}</small></div>
        </div>
        <div class="bi-filter-presets" role="group" aria-label="Períodos predefinidos">
            @foreach(['7d' => '7 dias', '30d' => '30 dias', '90d' => '90 dias', 'month' => 'Este mês'] as $key => $label)
                <a class="bi-filter-pill {{ $period === $key ? 'is-selected' : '' }}" href="{{ route('admin.dashboard', ['period' => $key]) }}" @if($period === $key) aria-current="page" @endif>{{ $label }}</a>
            @endforeach
        </div>
        <form method="GET" action="{{ route('admin.dashboard') }}" class="bi-custom-filter">
            <input type="hidden" name="period" value="custom">
            <label>De <input aria-label="Início do período" type="date" name="start" max="{{ now()->toDateString() }}" value="{{ $startDate }}" required></label>
            <label>Até <input aria-label="Fim do período" type="date" name="end" max="{{ now()->toDateString() }}" value="{{ $endDate }}" required></label>
            <button type="submit" class="bi-button bi-button-dark">Aplicar</button>
        </form>
    </section>

    <div class="bi-section-caption"><span>INDICADORES PRINCIPAIS</span><span>Comparações por data de criação, quando indicadas</span></div>
    <section class="bi-kpi-grid" aria-label="Indicadores principais">
        <article class="bi-kpi bi-kpi-featured">
            <div class="bi-kpi-top"><span>Total de reservas</span><span class="bi-kpi-icon">▤</span></div>
            <div class="bi-kpi-value">{{ number_format($reservationsCount, 0, ',', '.') }}</div>
            <div class="bi-kpi-foot">
                @if($previousReservations > 0)
                    @php($bookingVariation = ($reservationsCount - $previousReservations) / $previousReservations * 100)
                    <span class="bi-trend {{ $bookingVariation >= 0 ? 'is-up' : 'is-down' }}">{{ $bookingVariation >= 0 ? '↗' : '↘' }} {{ number_format(abs($bookingVariation), 1, ',', '.') }}%</span>
                    <span>vs. período anterior</span>
                @else
                    <span class="bi-kpi-muted">Anterior: {{ $previousReservations }} reservas</span>
                @endif
            </div>
        </article>
        <article class="bi-kpi">
            <div class="bi-kpi-top"><span>Ocupação média</span><span class="bi-kpi-icon bi-icon-emerald">▥</span></div>
            <div class="bi-kpi-value">{{ number_format($occupancyAverage, 1, ',', '.') }}<small>%</small></div>
            <div class="bi-kpi-foot"><span>Quartos ocupados / ativos, por diária</span></div>
            <div class="bi-kpi-meter"><span style="width:{{ min(100, max(0, $occupancyAverage)) }}%"></span></div>
        </article>
        <article class="bi-kpi">
            <div class="bi-kpi-top"><span>Quartos disponíveis hoje</span><span class="bi-kpi-icon bi-icon-blue">⌂</span></div>
            <div class="bi-kpi-value">{{ $availableToday }} <small>/ {{ $totalRooms }}</small></div>
            <div class="bi-kpi-foot"><span>{{ $occupiedToday }} ocupado(s) · {{ $blockedToday }} em bloqueio/manutenção</span></div>
        </article>
        @if($canFinance)
            <article class="bi-kpi bi-kpi-finance">
                <div class="bi-kpi-top"><span>Recebimentos no período</span><span class="bi-kpi-icon bi-icon-gold">R$</span></div>
                <div class="bi-kpi-value bi-money">R$ {{ number_format($received, 2, ',', '.') }}</div>
                <div class="bi-kpi-foot">
                    @if($previousReceived > 0)
                        @php($financeVariation = ($received - $previousReceived) / $previousReceived * 100)
                        <span class="bi-trend {{ $financeVariation >= 0 ? 'is-up' : 'is-down' }}">{{ $financeVariation >= 0 ? '↗' : '↘' }} {{ number_format(abs($financeVariation), 1, ',', '.') }}%</span>
                        <span>vs. período anterior</span>
                    @else
                        <span class="bi-kpi-muted">Pagamentos aprovados · modo simulado</span>
                    @endif
                </div>
            </article>
        @else
            <article class="bi-kpi">
                <div class="bi-kpi-top"><span>Check-ins previstos hoje</span><span class="bi-kpi-icon bi-icon-gold">↘</span></div>
                <div class="bi-kpi-value">{{ $arrivalToday }}</div>
                <div class="bi-kpi-foot"><span>Reservas confirmadas para hoje</span></div>
            </article>
        @endif
    </section>

    <section class="bi-secondary-kpis" aria-label="Indicadores operacionais">
        <div class="bi-mini"><span class="bi-mini-symbol">↘</span><div><small>Check-ins hoje</small><strong>{{ $arrivalToday }}</strong></div><span class="bi-mini-note">Previstos</span></div>
        <div class="bi-mini"><span class="bi-mini-symbol">↗</span><div><small>Check-outs hoje</small><strong>{{ $departureToday }}</strong></div><span class="bi-mini-note">Previstos</span></div>
        <div class="bi-mini"><span class="bi-mini-symbol">◷</span><div><small>Reservas pendentes</small><strong>{{ $pending }}</strong></div><span class="bi-mini-note">Não expiradas</span></div>
        <div class="bi-mini"><span class="bi-mini-symbol">✧</span><div><small>Tarefas de limpeza</small><strong>{{ $cleaningPending }}</strong></div><span class="bi-mini-note">Em aberto</span></div>
    </section>

    <div class="bi-chart-grid">
        <section class="bi-panel bi-panel-large">
            <div class="bi-panel-head">
                <div><span class="bi-eyebrow">DESEMPENHO</span><h2>Evolução da ocupação</h2><p>Percentual diário de quartos ativos ocupados</p></div>
                <span class="bi-chart-key"><i class="bi-dot-emerald"></i> Ocupação (%)</span>
            </div>
            <div class="bi-chart-slot" data-bi-chart="occupancy" role="img" aria-label="Gráfico de ocupação diária em porcentagem"></div>
            <div class="bi-chart-under"><span>0% = sem ocupação</span><strong>Média {{ number_format($occupancyAverage, 1, ',', '.') }}%</strong><span>100% = ocupação total</span></div>
        </section>
        <section class="bi-panel">
            <div class="bi-panel-head"><div><span class="bi-eyebrow">DEMANDA</span><h2>Novas reservas</h2><p>Reservas criadas por dia</p></div><span class="bi-chart-key"><i class="bi-dot-gold"></i> Reservas</span></div>
            <div class="bi-chart-slot" data-bi-chart="reservations" role="img" aria-label="Gráfico diário de novas reservas"></div>
            <div class="bi-chart-under"><span>Dados de criação da reserva</span><strong>{{ $reservationsCount }} no período</strong></div>
        </section>

        @if($canFinance)
            <section class="bi-panel bi-panel-large">
                <div class="bi-panel-head"><div><span class="bi-eyebrow">FLUXO FINANCEIRO</span><h2>Recebimentos e despesas</h2><p>Valores registrados no período, em reais</p></div><div class="bi-legend"><span class="bi-chart-key"><i class="bi-dot-emerald"></i> Recebido</span><span class="bi-chart-key"><i class="bi-dot-gold"></i> Despesas</span></div></div>
                <div class="bi-chart-slot" data-bi-chart="finance" role="img" aria-label="Gráfico de recebimentos e despesas diários"></div>
                <div class="bi-finance-summary"><div><small>Recebido</small><strong>R$ {{ number_format($received, 2, ',', '.') }}</strong></div><div><small>Despesas</small><strong>R$ {{ number_format($spent, 2, ',', '.') }}</strong></div><div><small>Saldo registrado</small><strong class="{{ $received - $spent < 0 ? 'bi-negative' : '' }}">R$ {{ number_format($received - $spent, 2, ',', '.') }}</strong></div></div>
                <p class="bi-fineprint">Ambiente de demonstração: recebimentos refletem pagamentos simulados aprovados, não transações bancárias.</p>
            </section>
        @endif
        <section class="bi-panel {{ $canFinance ? '' : 'bi-panel-large' }}">
            <div class="bi-panel-head"><div><span class="bi-eyebrow">DISTRIBUIÇÃO</span><h2>Status das reservas</h2><p>Reservas criadas no período selecionado</p></div></div>
            @php
                $confirmedStatusCount = collect($statusCounts)->whereIn('key', ['confirmada', 'checkin', 'checkout'])->sum('count');
                $waitingStatusCount = collect($statusCounts)->whereIn('key', ['pendente', 'aguardando_pagamento'])->sum('count');
                $otherStatusCount = max(0, $reservationsCount - $confirmedStatusCount - $waitingStatusCount);
                $confirmedCutoff = $reservationsCount ? round($confirmedStatusCount / $reservationsCount * 100, 2) : 0;
                $waitingCutoff = $reservationsCount ? round(($confirmedStatusCount + $waitingStatusCount) / $reservationsCount * 100, 2) : 0;
            @endphp
            <div class="cs-status-dashboard">
                <div class="cs-status-donut" style="--cs-confirmed:{{ $confirmedCutoff }}%; --cs-pending:{{ $waitingCutoff }}%" role="img" aria-label="{{ $reservationsCount }} reservas: {{ $confirmedStatusCount }} confirmadas ou concluídas; {{ $waitingStatusCount }} pendentes; {{ $otherStatusCount }} outras">
                    <div class="cs-status-donut-inner"><strong>{{ $reservationsCount }}</strong><span>reservas</span></div>
                </div>
                <div class="cs-status-legend">
                    <div><span><i class="cs-ok"></i>Confirmadas / hospedadas</span><b>{{ $confirmedStatusCount }}</b></div>
                    <div><span><i class="cs-wait"></i>Pendentes</span><b>{{ $waitingStatusCount }}</b></div>
                    <div><span><i class="cs-other"></i>Outras</span><b>{{ $otherStatusCount }}</b></div>
                </div>
            </div>
            <div class="bi-status-list">
                @forelse($statusCounts as $item)
                    <div class="bi-status-item"><div class="bi-status-line"><span>{{ $item['label'] }}</span><strong>{{ $item['count'] }}</strong></div><div class="bi-status-track"><span class="bi-status-fill bi-status-{{ $item['key'] }}" style="width:{{ $reservationsCount > 0 ? round($item['count'] / $reservationsCount * 100, 1) : 0 }}%"></span></div></div>
                @empty
                    <div class="bi-no-data">Nenhuma reserva criada neste período.</div>
                @endforelse
            </div>
        </section>
    </div>

    <div class="bi-bottom-grid">
        <section class="bi-panel">
            <div class="bi-panel-head"><div><span class="bi-eyebrow">ACOMODAÇÕES</span><h2>Categorias mais reservadas</h2><p>Unidades reservadas com entrada no período</p></div></div>
            @forelse($topRoomTypes as $item)
                <div class="bi-rank-row"><span class="bi-rank-number">{{ str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT) }}</span><span>{{ $item->name }}</span><strong>{{ $item->total }} {{ $item->total == 1 ? 'reserva' : 'reservas' }}</strong></div>
            @empty
                <div class="bi-no-data">Nenhuma acomodação reservada no período.</div>
            @endforelse
        </section>
        @if($canReservations)
            <section class="bi-panel">
                <div class="bi-panel-head"><div><span class="bi-eyebrow">PRÓXIMAS CHEGADAS</span><h2>Agenda da recepção</h2><p>Reservas confirmadas com entrada futura</p></div><a class="bi-small-link" href="{{ route('admin.calendar') }}">Ver calendário ↗</a></div>
                @forelse($upcoming as $booking)
                    <div class="bi-arrival-row"><span class="bi-date-box"><strong>{{ $booking->check_in->format('d') }}</strong><small>{{ mb_strtoupper($booking->check_in->translatedFormat('M')) }}</small></span><div class="bi-arrival-info"><strong>{{ $booking->guest?->name ?? 'Hóspede' }}</strong><small>{{ $booking->rooms->pluck('number')->join(', ') ?: 'Acomodação não informada' }} · {{ $booking->code }}</small></div><a href="{{ route('admin.reservations.show', $booking) }}" aria-label="Ver reserva {{ $booking->code }}">↗</a></div>
                @empty
                    <div class="bi-no-data">Sem chegadas futuras confirmadas.</div>
                @endforelse
            </section>
        @elseif($canHousekeeping)
            <section class="bi-panel bi-actions-panel"><span class="bi-eyebrow">AÇÕES RÁPIDAS</span><h2>Governança</h2><p>Consulte as tarefas de limpeza e manutenção para organizar a operação da pousada.</p><a class="bi-button bi-button-dark" href="{{ route('admin.housekeeping.index') }}">Abrir governança ↗</a></section>
        @endif
    </div>

    @if($canReservations)
        <section class="bi-panel bi-recent-panel">
            <div class="bi-panel-head"><div><span class="bi-eyebrow">ÚLTIMAS MOVIMENTAÇÕES</span><h2>Reservas recentes</h2><p>Últimos registros, independentemente do período filtrado</p></div><a class="bi-small-link" href="{{ route('admin.reservations.index') }}">Todas as reservas ↗</a></div>
            <div class="bi-table-scroll"><table class="bi-table"><thead><tr><th>Reserva</th><th>Hóspede</th><th>Check-in</th><th>Check-out</th><th>Status atual</th>@if($canFinance)<th>Valor contratado</th>@endif<th></th></tr></thead><tbody>
                @forelse($recent as $booking)
                    <tr><td><strong>{{ $booking->code }}</strong></td><td>{{ $booking->guest?->name ?? 'Hóspede' }}</td><td>{{ $booking->check_in->format('d/m/Y') }}</td><td>{{ $booking->check_out->format('d/m/Y') }}</td><td><span class="bi-status-chip bi-chip-{{ $booking->status }}">{{ str_replace('_', ' ', ucfirst($booking->status)) }}</span></td>@if($canFinance)<td class="bi-value-cell">R$ {{ number_format((float) $booking->total, 2, ',', '.') }}</td>@endif<td><a class="bi-row-link" href="{{ route('admin.reservations.show', $booking) }}" aria-label="Detalhes da reserva {{ $booking->code }}">↗</a></td></tr>
                @empty
                    <tr><td colspan="{{ $canFinance ? 7 : 6 }}" class="bi-no-data">Nenhuma reserva cadastrada.</td></tr>
                @endforelse
            </tbody></table></div>
        </section>
    @endif

    <div class="bi-footnote"><span>●</span> Indicadores calculados a partir do banco de dados local. Reservas por criação; ocupação por noites; disponibilidade de hoje considera bloqueios cadastrados e manutenção.</div>
</div>
<script type="application/json" id="bi-dashboard-data">@json($chartData)</script>
@endsection
