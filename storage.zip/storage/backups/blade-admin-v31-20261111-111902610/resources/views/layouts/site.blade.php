<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#173e34">
    <title>@yield('title', 'Pousada Costa Serena') · {{ \App\Models\Setting::read('pousada_nome', 'Pousada Costa Serena') }}</title>
    <meta name="description" content="Pousada Costa Serena — conforto, natureza e experiências inesquecíveis em uma estadia acolhedora.">
    @if(file_exists(public_path('build/manifest.json')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @else
        <link rel="stylesheet" href="{{ asset('assets/app.css') }}">
        <script src="{{ asset('assets/app.js') }}" defer></script>
    @endif
    <link rel="stylesheet" href="{{ asset('assets/site-enhancements.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/costa-site-v3.css') }}?v=3">
    <script src="{{ asset('assets/site-enhancements.js') }}" defer></script>
    <script src="{{ asset('assets/costa-ui-v3.js') }}?v=3" defer></script>
</head>
<body class="cs-site">
    <header class="site-header cs-site-header">
        <div class="wrap cs-nav">
            <a class="brand cs-brand" href="{{ route('home') }}" aria-label="Pousada Costa Serena — início">
                <img src="{{ asset('assets/brand.svg') }}" alt="" width="60" height="48">
                <span>{{ \App\Models\Setting::read('pousada_nome', 'Pousada Costa Serena') }}</span>
            </a>
            <button id="csMenuToggle" class="cs-menu-toggle" type="button" aria-controls="csMenu" aria-expanded="false" aria-label="Abrir menu de navegação">☰</button>
            <nav class="cs-navlinks" id="csMenu" aria-label="Menu principal">
                <a class="{{ request()->routeIs('home') ? 'is-current' : '' }}" href="{{ route('home') }}">Início</a>
                <a class="{{ request()->routeIs('rooms.*') ? 'is-current' : '' }}" href="{{ route('rooms.index') }}">Acomodações</a>
                <a href="{{ route('page.show', 'experiencias') }}">Experiências</a>
                <a href="{{ route('page.show', 'sobre') }}">A pousada</a>
                <a href="{{ route('page.show', 'galeria') }}">Galeria</a>
                <a href="{{ route('contact') }}">Contato</a>
            </nav>
            <div class="cs-nav-actions">
                @auth
                    <a class="cs-account-link" href="{{ auth()->user()->hasRole('hospede') ? route('guest.dashboard') : route('admin.dashboard') }}">♙ <span>Minha área</span></a>
                @else
                    <a class="cs-account-link" href="{{ route('login') }}">♙ <span>Minha Reserva</span></a>
                @endauth
                <a class="cs-reserve-top" href="{{ route('rooms.index') }}">▣ <span>Reservar agora</span></a>
            </div>
        </div>
    </header>
    @if(session('success'))
        <div class="wrap alert success" role="status">{{ session('success') }}</div>
    @endif
    @if($errors->any())
        <div class="wrap alert error" role="alert"><strong>Revise os dados:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
    @endif
    <main id="main">@yield('content')</main>
    <footer class="footer cs-footer">
        <div class="wrap footer-grid">
            <div><a class="brand cs-brand cs-footer-brand" href="{{ route('home') }}"><img width="55" src="{{ asset('assets/brand.svg') }}" alt=""><span>{{ \App\Models\Setting::read('pousada_nome', 'Pousada Costa Serena') }}</span></a><p>Conforto, natureza e hospitalidade. Sua próxima pausa começa aqui.</p><small>Projeto fictício e imagens ilustrativas para demonstração local.</small></div>
            <div><strong>Explore</strong><a href="{{ route('rooms.index') }}">Acomodações</a><a href="{{ route('page.show', 'sobre') }}">Nossa história</a><a href="{{ route('page.show', 'experiencias') }}">Experiências</a><a href="{{ route('page.show', 'galeria') }}">Galeria</a></div>
            <div><strong>Informações</strong><a href="{{ route('page.show', 'cancelamento') }}">Cancelamentos</a><a href="{{ route('page.show', 'termos') }}">Termos de uso</a><a href="{{ route('page.show', 'privacidade') }}">Privacidade</a><a href="{{ route('contact') }}">Contato</a></div>
        </div>
        <div class="wrap footer-bottom">© {{ date('Y') }} Pousada Costa Serena · Ambiente de demonstração</div>
    </footer>
    @php($whatsapp = preg_replace('/\D/', '', \App\Models\Setting::read('whatsapp', '')))
    @if($whatsapp)
        <a class="wa-float" rel="noopener noreferrer" target="_blank" href="https://wa.me/{{ $whatsapp }}" aria-label="Fale conosco pelo WhatsApp">✆</a>
    @endif
</body>
</html>
