<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#082f32">
    <title>@yield('title', 'Painel administrativo') · Pousada Costa Serena</title>
    @if(file_exists(public_path('build/manifest.json')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @else
        <link rel="stylesheet" href="{{ asset('assets/app.css') }}">
        <script src="{{ asset('assets/app.js') }}" defer></script>
    @endif
    <link rel="stylesheet" href="{{ asset('assets/admin-studio.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/costa-admin-v3.css') }}?v=3">
    <script src="{{ asset('assets/admin-studio.js') }}" defer></script>
    <script src="{{ asset('assets/costa-admin-v3.js') }}?v=3" defer></script>
</head>
<body class="admin-body cs-admin-body">
<div class="app-shell cs-app-shell">
    <aside class="sidebar cs-sidebar" id="csAdminSidebar" aria-label="Navegação administrativa">
        <a class="brand inverse cs-admin-brand" href="{{ route('admin.dashboard') }}"><img src="{{ asset('assets/brand.svg') }}" width="63" alt=""><span>{{ \App\Models\Setting::read('pousada_nome', 'Pousada Costa Serena') }}</span></a>
        <small class="cs-admin-sublabel">PAINEL ADMINISTRATIVO</small>
        <div class="cs-sidebar-divider"></div>
        <small class="cs-menu-label">MENU PRINCIPAL</small>
        <a class="{{ request()->routeIs('admin.dashboard') ? 'is-active' : '' }}" href="{{ route('admin.dashboard') }}"><span class="cs-nav-icon">⌂</span><span>Visão geral</span></a>
        @can('manage-reservations')
            <a class="{{ request()->routeIs('admin.reservations.*') ? 'is-active' : '' }}" href="{{ route('admin.reservations.index') }}"><span class="cs-nav-icon">▣</span><span>Reservas</span></a>
        @endcan
        <a class="{{ request()->routeIs('admin.calendar*') ? 'is-active' : '' }}" href="{{ route('admin.calendar') }}"><span class="cs-nav-icon">▦</span><span>Calendário</span></a>
        @can('manage-rooms')
            <a class="{{ request()->routeIs('admin.rooms.*') ? 'is-active' : '' }}" href="{{ route('admin.rooms.index') }}"><span class="cs-nav-icon">▤</span><span>Acomodações</span></a>
        @endcan
        @can('manage-reservations')
            <a class="{{ request()->routeIs('admin.guests.*') ? 'is-active' : '' }}" href="{{ route('admin.guests.index') }}"><span class="cs-nav-icon">♙</span><span>Hóspedes</span></a>
        @endcan
        @can('manage-finance')
            <a class="{{ request()->routeIs('admin.finance.*') ? 'is-active' : '' }}" href="{{ route('admin.finance.index') }}"><span class="cs-nav-icon">＄</span><span>Financeiro</span></a>
        @endcan
        @can('manage-settings')
            <a class="{{ request()->routeIs('admin.rates.*') ? 'is-active' : '' }}" href="{{ route('admin.rates.index') }}"><span class="cs-nav-icon">◇</span><span>Tarifas e promoções</span></a>
            <div class="cs-sidebar-divider"></div>
            <small class="cs-menu-label">SITE E CONTEÚDO</small>
            <a class="{{ request()->routeIs('admin.pages.*') ? 'is-active' : '' }}" href="{{ route('admin.pages.index') }}"><span class="cs-nav-icon">▧</span><span>Páginas do site</span></a>
            <a class="{{ request()->routeIs('admin.media.*') ? 'is-active' : '' }}" href="{{ route('admin.media.index') }}"><span class="cs-nav-icon">▧</span><span>Imagens do site</span></a>
        @endcan
        <div class="cs-sidebar-divider"></div>
        <small class="cs-menu-label">GESTÃO E SISTEMA</small>
        @can('manage-housekeeping')
            <a class="{{ request()->routeIs('admin.housekeeping.*') ? 'is-active' : '' }}" href="{{ route('admin.housekeeping.index') }}"><span class="cs-nav-icon">♧</span><span>Governança</span></a>
        @endcan
        @can('manage-settings')
            <a class="{{ request()->routeIs('admin.staff.*') ? 'is-active' : '' }}" href="{{ route('admin.staff.index') }}"><span class="cs-nav-icon">♧</span><span>Funcionários</span></a>
        @endcan
        @can('manage-finance')
            <a class="{{ request()->routeIs('admin.reports') ? 'is-active' : '' }}" href="{{ route('admin.reports') }}"><span class="cs-nav-icon">▥</span><span>Relatórios</span></a>
        @endcan
        @can('manage-settings')
            <a class="{{ request()->routeIs('admin.settings.*') ? 'is-active' : '' }}" href="{{ route('admin.settings.index') }}"><span class="cs-nav-icon">⚙</span><span>Configurações</span></a>
        @endcan
        <div class="sidebar-bottom cs-sidebar-bottom">
            <div class="cs-sidebar-place"><span>✦</span><small>Bem-vindo à Costa Serena<br><b>Gestão com tranquilidade.</b></small></div>
            <a href="{{ route('home') }}" target="_blank" rel="noopener noreferrer">↗ Ver site público</a>
            <form method="POST" action="{{ route('logout') }}">@csrf<button type="submit">Sair da conta</button></form>
        </div>
    </aside>
    <div class="admin-main cs-admin-main">
        <header class="admin-top cs-admin-top">
            <button type="button" id="navToggle" class="mobile-toggle cs-admin-menu-toggle" aria-controls="csAdminSidebar" aria-label="Abrir menu administrativo" aria-expanded="false">☰</button>
            <div class="cs-top-title"><small>PAINEL ADMINISTRATIVO</small><strong>@yield('title', 'Visão geral')</strong></div>
            <div class="admin-command cs-command">
                <button type="button" id="adminCommandToggle" class="admin-command-toggle" aria-controls="adminCommandPanel" aria-expanded="false" aria-label="Pesquisar módulos">⌕ <span>Buscar no sistema...</span><kbd>Ctrl K</kbd></button>
                <div id="adminCommandPanel" class="admin-command-panel" hidden>
                    <label class="admin-command-field">Buscar módulo<input id="adminCommandInput" type="search" autocomplete="off" placeholder="Reservas, páginas, financeiro..."></label>
                    <nav id="adminCommandLinks" aria-label="Resultados da pesquisa">
                        <a href="{{ route('admin.dashboard') }}">⌂ Visão geral</a>
                        <a href="{{ route('admin.calendar') }}">▦ Calendário</a>
                        @can('manage-reservations')<a href="{{ route('admin.reservations.index') }}">▣ Reservas</a><a href="{{ route('admin.guests.index') }}">♙ Hóspedes</a>@endcan
                        @can('manage-rooms')<a href="{{ route('admin.rooms.index') }}">▤ Acomodações</a>@endcan
                        @can('manage-finance')<a href="{{ route('admin.finance.index') }}">＄ Financeiro</a><a href="{{ route('admin.reports') }}">▥ Relatórios</a>@endcan
                        @can('manage-housekeeping')<a href="{{ route('admin.housekeeping.index') }}">♧ Governança</a>@endcan
                        @can('manage-settings')<a href="{{ route('admin.rates.index') }}">◇ Tarifas</a><a href="{{ route('admin.pages.index') }}">▧ Páginas</a><a href="{{ route('admin.media.index') }}">▧ Imagens do site</a><a href="{{ route('admin.staff.index') }}">♙ Funcionários</a><a href="{{ route('admin.settings.index') }}">⚙ Configurações</a>@endcan
                    </nav>
                    <p id="adminCommandEmpty" hidden>Nenhum módulo encontrado.</p>
                </div>
            </div>
            <a class="cs-top-website" href="{{ route('home') }}" title="Abrir site público" target="_blank" rel="noopener noreferrer">↗ <span>Ver site</span></a>
            @can('manage-reservations')<a class="cs-top-alert" href="{{ route('admin.reservations.index') }}" title="Consultar reservas" aria-label="Ver reservas">♧</a>@endcan
            <div class="cs-top-user"><span class="cs-avatar">{{ mb_strtoupper(mb_substr(auth()->user()->name, 0, 1)) }}</span><span><b>{{ auth()->user()->name }}</b><small>{{ auth()->user()->role?->name ?? 'Equipe' }}</small></span></div>
        </header>
        <section class="admin-content cs-admin-content">
            @if(session('success'))<div class="alert success" role="status">{{ session('success') }}</div>@endif
            @if($errors->any())
                <div class="alert error" role="alert"><strong>Revise os dados:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
            @endif
            @yield('content')
        </section>
    </div>
</div>
</body>
</html>
