<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\DemoSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminVisualReferenceV4Test extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DemoSeeder::class);
    }

    public function test_administrator_dashboard_renders_matching_layout_and_real_kpis(): void
    {
        $admin = User::where('email', 'admin@costaserena.test')->firstOrFail();

        $this->actingAs($admin)->get('/admin')
            ->assertOk()
            ->assertSee('Painel Administrativo')
            ->assertSee('ref-sidebar')
            ->assertSee('admin-reference-v4.css')
            ->assertSee('Status das Reservas')
            ->assertSee('Evolução da Ocupação')
            ->assertSee('Recebimentos no período')
            ->assertSee('Taxa de Ocupação por Acomodação')
            ->assertSee('bi-dashboard-data');
    }

    public function test_receptionist_dashboard_hides_financial_metrics(): void
    {
        $employee = User::where('email', 'recepcao@costaserena.test')->firstOrFail();

        $this->actingAs($employee)->get('/admin')
            ->assertOk()
            ->assertDontSee('Recebimentos no período')
            ->assertDontSee('Recebimentos por Método')
            ->assertSee('Operação de Hoje');
    }

    public function test_admin_can_use_dashboard_period_filters(): void
    {
        $admin = User::where('email', 'admin@costaserena.test')->firstOrFail();

        $this->actingAs($admin)->get('/admin?period=7d')
            ->assertOk()->assertSee('Últimos 7 dias');
        $this->actingAs($admin)->get('/admin?period=30d')
            ->assertOk()->assertSee('Últimos 30 dias');
    }
}
