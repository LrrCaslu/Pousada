<?php

namespace Tests\Feature;

use App\Models\Setting;
use App\Models\User;
use Database\Seeders\DemoSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminMediaTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DemoSeeder::class);
    }

    public function test_admin_can_select_hero_from_whitelisted_local_images(): void
    {
        $admin = User::where('email', 'admin@costaserena.test')->firstOrFail();
        $this->actingAs($admin)->get('/admin/midias')->assertOk()->assertSee('Biblioteca de fotografias');
        $this->actingAs($admin)->post('/admin/midias/destaque', [
            'hero_photo' => 'piscina-iluminada.webp',
        ])->assertRedirect('/admin/midias');
        $this->assertSame('piscina-iluminada.webp', Setting::read('site_hero_photo'));
        $this->get('/')->assertOk()->assertSee('piscina-iluminada.webp');
    }

    public function test_admin_cannot_inject_arbitrary_path_as_hero_photo(): void
    {
        $admin = User::where('email', 'admin@costaserena.test')->firstOrFail();
        $this->actingAs($admin)->post('/admin/midias/destaque', [
            'hero_photo' => '../../.env',
        ])->assertSessionHasErrors('hero_photo');
    }

    public function test_staff_without_permission_cannot_access_media_manager(): void
    {
        $user = User::where('email', 'recepcao@costaserena.test')->firstOrFail();
        $this->actingAs($user)->get('/admin/midias')->assertForbidden();
        $this->actingAs($user)->post('/admin/midias/destaque', [
            'hero_photo' => 'suite-serena.webp',
        ])->assertForbidden();
    }
}
