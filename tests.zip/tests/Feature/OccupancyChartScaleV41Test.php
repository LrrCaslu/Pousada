<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\DemoSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class OccupancyChartScaleV41Test extends TestCase
{
    use RefreshDatabase;

    public function test_dashboard_passes_active_room_capacity_to_combined_chart(): void
    {
        $this->seed(DemoSeeder::class);
        $admin = User::where('email', 'admin@costaserena.test')->firstOrFail();

        $this->actingAs($admin)->get('/admin?period=30d')
            ->assertOk()
            ->assertSee('data-ref-chart="occupancy"', false)
            ->assertSee('refOccupancyScale', false)
            ->assertSee('refOccupancyZoom', false)
            ->assertSee('Quartos ocupados')
            ->assertSee('"totalRooms":12', false)
            ->assertSee('"occupiedRooms":', false)
            ->assertSee('"occupancy":', false);
    }
}
