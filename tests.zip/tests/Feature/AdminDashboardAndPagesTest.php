<?php

namespace Tests\Feature;

use App\Models\Page;
use App\Models\User;
use Database\Seeders\DemoSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminDashboardAndPagesTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DemoSeeder::class);
    }

    public function test_administrator_sees_dashboard_with_real_indicators(): void
    {
        $user = User::where('email', 'admin@costaserena.test')->firstOrFail();
        $this->actingAs($user)->get('/admin')
            ->assertOk()
            ->assertSee('Visão geral')
            ->assertSee('Evolução da ocupação')
            ->assertSee('Recebimentos no período')
            ->assertSee('bi-dashboard-data');
    }

    public function test_dashboard_accepts_presets_and_custom_dates(): void
    {
        $user = User::where('email', 'admin@costaserena.test')->firstOrFail();
        $this->actingAs($user)->get('/admin?period=7d')->assertOk();
        $this->actingAs($user)->get('/admin?period=month')->assertOk();
        $this->actingAs($user)->get('/admin?period=custom&start=' . now()->subDays(4)->toDateString() . '&end=' . now()->toDateString())
            ->assertOk();
    }

    public function test_invalid_custom_date_range_is_rejected(): void
    {
        $user = User::where('email', 'admin@costaserena.test')->firstOrFail();
        $this->actingAs($user)->get('/admin?period=custom&start=2026-01-20&end=2026-01-01')
            ->assertSessionHasErrors(['end']);
    }

    public function test_reception_does_not_see_financial_values(): void
    {
        $user = User::where('email', 'recepcao@costaserena.test')->firstOrFail();
        $this->actingAs($user)->get('/admin')
            ->assertOk()
            ->assertDontSee('Recebimentos no período');
    }

    public function test_page_editor_loads_and_saves_existing_page(): void
    {
        $user = User::where('email', 'admin@costaserena.test')->firstOrFail();
        $page = Page::where('slug', 'sobre')->firstOrFail();
        $this->actingAs($user)->get('/admin/paginas?page=' . $page->id)
            ->assertOk()
            ->assertSee('Pré-visualização');
        $this->actingAs($user)->put('/admin/paginas/' . $page->id, [
            'title' => 'Nossa história',
            'body' => "Bem-vindo à pousada.\nNosso espaço.",
            'published' => 0,
        ])->assertRedirect('/admin/paginas?page=' . $page->id);

        $this->assertDatabaseHas('pages', [
            'id' => $page->id, 'title' => 'Nossa história', 'published' => 0,
        ]);
        $this->get('/pagina/sobre')->assertNotFound();
    }

    public function test_staff_without_settings_permission_cannot_edit_pages(): void
    {
        $user = User::where('email', 'recepcao@costaserena.test')->firstOrFail();
        $this->actingAs($user)->get('/admin/paginas')->assertForbidden();
    }
}
