<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\DemoSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminUnifiedV5Test extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DemoSeeder::class);
    }

    public function test_admin_sees_consistent_modules_without_missing_blade_variables(): void
    {
        $admin = User::where('email', 'admin@costaserena.test')->firstOrFail();

        foreach ([
            '/admin/reservas' => 'Central de reservas',
            '/admin/reservas/criar' => 'Criar uma reserva',
            '/admin/quartos' => 'Gestão de acomodações',
            '/admin/hospedes' => 'Diretório de hóspedes',
            '/admin/financeiro' => 'Gestão financeira',
            '/admin/governanca' => 'Governança e limpeza',
            '/admin/tarifas' => 'Tarifas e promoções',
            '/admin/funcionarios' => 'Gestão da equipe',
            '/admin/configuracoes' => 'Configurações da pousada',
            '/admin/calendario' => 'Calendário de hospedagens',
            '/admin/relatorios' => 'Relatórios gerenciais',
            '/admin/paginas' => 'Páginas do site',
            '/admin/midias' => 'Imagens do site',
        ] as $url => $expected) {
            $this->actingAs($admin)->get($url)
                ->assertOk()
                ->assertSee($expected)
                ->assertSee('admin-unified-v5.css')
                ->assertSee('admin-unified-v5.js');
        }
    }

    public function test_receptionist_cannot_access_finance_staff_and_pages(): void
    {
        $receptionist = User::where('email', 'recepcao@costaserena.test')->firstOrFail();
        foreach (['/admin/financeiro', '/admin/funcionarios', '/admin/paginas', '/admin/midias'] as $url) {
            $this->actingAs($receptionist)->get($url)->assertForbidden();
        }
    }

    public function test_unauthenticated_user_must_sign_in_for_admin(): void
    {
        $this->get('/admin/quartos')->assertRedirect('/entrar');
    }
}
