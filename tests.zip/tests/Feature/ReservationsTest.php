<?php
namespace Tests\Feature;
use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Database\Seeders\DemoSeeder;
use App\Models\{Room,Reservation,User};
use App\Services\{ReservationService,PaymentService};
use Illuminate\Validation\ValidationException;
class ReservationsTest extends TestCase {
 use RefreshDatabase;
 protected function setUp():void {parent::setUp();$this->seed(DemoSeeder::class);}
 private function data():array {return ['room_id'=>Room::firstOrFail()->id,'check_in'=>now()->addDays(365)->toDateString(),'check_out'=>now()->addDays(368)->toDateString(),'adults'=>2,'children'=>0,'name'=>'Reserva Teste','email'=>'reserva@exemplo.test','payment_method'=>'pix'];}
 public function test_booking_and_prevents_overlapping():void {
  $service=app(ReservationService::class);$data=$this->data();$first=$service->create($data);$this->assertEquals('aguardando_pagamento',$first->status);
  $this->expectException(ValidationException::class);$service->create($data);
 }
 public function test_guest_cannot_see_other_users_receipt():void {
  $res=Reservation::firstOrFail();$user=User::where('email','hospede@costaserena.test')->firstOrFail();$this->actingAs($user)->get('/comprovante/'.$res->code)->assertForbidden();
 }
 public function test_simulated_payment_approves_reservation():void {
  $res=app(ReservationService::class)->create($this->data());$payment=$res->payments->first();
  app(PaymentService::class)->simulate($payment,'aprovado');$this->assertEquals('confirmada',$res->fresh()->status);
 }
 public function test_room_under_maintenance_is_unavailable():void {
   $data=$this->data();Room::findOrFail($data['room_id'])->update(['housekeeping_status'=>'manutencao']);
   $this->expectException(ValidationException::class);app(ReservationService::class)->create($data);
 }
 public function test_invalid_dates_are_rejected():void {
  $data=$this->data();$data['check_out']=$data['check_in'];$this->expectException(ValidationException::class);app(ReservationService::class)->create($data);
 }
}
