<?php
namespace Tests\Feature;
use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Database\Seeders\DemoSeeder;
class AuthAndPermissionsTest extends TestCase {
 use RefreshDatabase;
 protected function setUp():void {parent::setUp();$this->seed(DemoSeeder::class);}
 public function test_admin_can_sign_in():void {$this->post('/entrar',['email'=>'admin@costaserena.test','password'=>'Admin@12345'])->assertRedirect('/admin');$this->assertAuthenticated();}
 public function test_each_staff_member_can_access_admin_area():void {
  foreach(['recepcao@costaserena.test'=>'Recep@12345','financeiro@costaserena.test'=>'Finan@12345','governanca@costaserena.test'=>'Gover@12345'] as $email=>$password){$this->post('/entrar',['email'=>$email,'password'=>$password])->assertRedirect('/admin');$this->assertAuthenticated();$this->post('/sair');}
 }
 public function test_guest_cannot_access_admin():void {$this->post('/entrar',['email'=>'hospede@costaserena.test','password'=>'Hosp@12345'])->assertRedirect('/minha-conta');$this->get('/admin')->assertForbidden();}
 public function test_finance_cannot_manage_rooms():void {$user=\App\Models\User::where('email','financeiro@costaserena.test')->firstOrFail();$this->actingAs($user)->get('/admin/quartos')->assertForbidden();}
 public function test_public_home_renders():void {$this->get('/')->assertOk()->assertSee('Seu descanso começa');}
}
