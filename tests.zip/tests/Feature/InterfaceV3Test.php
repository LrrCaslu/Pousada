<?php

namespace Tests\Feature;

use App\Models\Page;
use App\Models\User;
use Database\Seeders\DemoSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class InterfaceV3Test extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DemoSeeder::class);
    }

    public function test_homepage_renders_local_images_and_booking_form(): void
    {
        $this->get('/')
            ->assertOk()
            ->assertSee('Conforto, natureza')
            ->assertSee('Consultar disponibilidade')
            ->assertSee('assets/photos/')
            ->assertSee('costa-site-v3.css');
    }

    public function test_administrator_can_open_dashboard_and_page_editor_without_missing_variables(): void
    {
        $admin = User::where('email', 'admin@costaserena.test')->firstOrFail();
        $this->actingAs($admin)->get('/admin')
            ->assertOk()
            ->assertSee('cs-status-donut')
            ->assertSee('costa-admin-v3.css');
        $this->actingAs($admin)->get('/admin/paginas')
            ->assertOk()
            ->assertSee('Publicadas no site')
            ->assertSee('Nova página');
    }

    public function test_admin_can_create_and_publish_a_new_page(): void
    {
        $admin = User::where('email', 'admin@costaserena.test')->firstOrFail();
        $this->actingAs($admin)->post('/admin/paginas', [
            'title' => 'Eventos especiais',
            'slug' => 'eventos-especiais',
            'body' => 'Conteúdo de demonstração.',
            'published' => 1,
        ])->assertRedirect();
        $this->assertDatabaseHas('pages', [
            'slug' => 'eventos-especiais', 'published' => 1,
        ]);
        $this->get('/pagina/eventos-especiais')->assertOk()->assertSee('Conteúdo de demonstração.');
    }

    public function test_receptionist_cannot_create_pages(): void
    {
        $employee = User::where('email', 'recepcao@costaserena.test')->firstOrFail();
        $this->actingAs($employee)->post('/admin/paginas', [
            'title' => 'Sem autorização', 'slug' => 'sem-autorizacao', 'published' => 1,
        ])->assertForbidden();
        $this->assertSame(0, Page::where('slug', 'sem-autorizacao')->count());
    }

    public function test_calendar_loads_without_relying_on_npm_assets(): void
    {
        $employee = User::where('email', 'recepcao@costaserena.test')->firstOrFail();
        $this->actingAs($employee)->get('/admin/calendario')
            ->assertOk()
            ->assertSee('reservation-calendar')
            ->assertSee('costa-admin-v3.js')
            ->assertSee('Mês anterior');
    }

    public function test_housekeeping_calendar_does_not_reveal_guest_names(): void
    {
        $employee = User::where('email', 'governanca@costaserena.test')->firstOrFail();
        $response = $this->actingAs($employee)->getJson('/admin/calendario/eventos?start='.
            now()->subDays(120)->toDateString().'&end='.now()->addDays(150)->toDateString());
        $response->assertOk();
        $this->assertStringNotContainsString('Hóspede Fictício', $response->getContent());
        $this->assertStringContainsString('Ocupado', $response->getContent());
    }
}
