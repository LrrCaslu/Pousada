<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\File;
use ParseError;
use Tests\TestCase;

class BladeCompilationRegressionTest extends TestCase
{
    public function test_all_blade_views_compile_into_valid_php_syntax(): void
    {
        foreach (File::allFiles(resource_path('views')) as $file) {
            $relative = $file->getRelativePathname();
            $compiled = Blade::compileString(File::get($file->getPathname()));

            try {
                // TOKEN_PARSE valida de fato a sintaxe PHP compilada, sem executar as views.
                token_get_all($compiled, TOKEN_PARSE);
            } catch (ParseError $exception) {
                $this->fail('A view ' . $relative . ' compilou PHP invalido: ' . $exception->getMessage());
            }
        }

        $this->assertTrue(true);
    }
}
