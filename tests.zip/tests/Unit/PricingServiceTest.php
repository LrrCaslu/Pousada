<?php
namespace Tests\Unit;
use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Database\Seeders\DemoSeeder;
use App\Models\{Room,Rate,Coupon};
use App\Services\PricingService;
class PricingServiceTest extends TestCase {
 use RefreshDatabase;
 protected function setUp():void {parent::setUp();$this->seed(DemoSeeder::class);}
 public function test_specific_date_overrides_base_tariff_and_coupon():void {
   $room=Room::with('type')->firstOrFail();$date=now()->addDays(400)->toDateString();$end=now()->addDays(401)->toDateString();
   Rate::create(['room_type_id'=>$room->room_type_id,'date'=>$date,'price'=>'500.00']);Coupon::create(['code'=>'TESTE10','type'=>'percent','value'=>10,'active'=>true]);
   $quote=app(PricingService::class)->quote($room,$date,$end,'TESTE10');$this->assertSame('500.00',$quote['base_total']);$this->assertSame('450.00',$quote['total']);
 }
}
