$ErrorActionPreference = 'Stop'
try {
    $sourceRoot = Split-Path -Parent $PSScriptRoot
    if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot 'artisan'))) {
        throw 'Extraia o ZIP completo antes de executar este arquivo.'
    }
    Write-Host '======================================================' -ForegroundColor Cyan
    Write-Host ' Pousada Costa Serena - Atualizar para versao 3' -ForegroundColor Cyan
    Write-Host '======================================================' -ForegroundColor Cyan
    Write-Host 'O instalador copia codigo e assets em conjunto e preserva .env, vendor, storage e MySQL.'
    $target = (Read-Host 'Caminho COMPLETO da pasta Laravel atual (onde esta artisan)').Trim().Trim('"')
    if ([string]::IsNullOrWhiteSpace($target)) {throw 'Caminho vazio.'}
    if (-not (Test-Path -LiteralPath (Join-Path $target 'artisan'))) { throw 'A pasta informada nao contem artisan.' }
    if (-not (Test-Path -LiteralPath (Join-Path $target 'composer.json'))) { throw 'A pasta informada nao contem composer.json.' }
    $sourceFull = [System.IO.Path]::GetFullPath($sourceRoot).TrimEnd([char]'\',[char]'/')
    $targetFull = [System.IO.Path]::GetFullPath($target).TrimEnd([char]'\',[char]'/')
    if ([string]::Equals($sourceFull, $targetFull, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'A pasta de origem e destino sao iguais. Para uso NOVO execute install.bat; para atualizar copie o ZIP em uma pasta separada.'
    }

    $paths = @(
      'app', 'bootstrap/app.php', 'bootstrap/providers.php', 'config',
      'routes', 'resources/views', 'resources/js', 'resources/css',
      'public/assets', 'public/index.php', 'public/.htaccess',
      'tests', 'scripts/verificar.php', 'composer.json', 'package.json', 'phpunit.xml'
    )
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmssfff'
    $backup = Join-Path $targetFull ('storage\backups\costa-v3-' + $stamp)
    $files = @()
    foreach ($relative in $paths) {
      $source = Join-Path $sourceFull $relative
      if (-not (Test-Path -LiteralPath $source)) { throw ('Arquivo de origem ausente: ' + $relative) }
      if (Test-Path -LiteralPath $source -PathType Container) {
        $files += Get-ChildItem -LiteralPath $source -File -Recurse | ForEach-Object {
          $full = $_.FullName.Substring($sourceFull.Length).TrimStart([char]'\',[char]'/')
          [PSCustomObject]@{Path=$full;File=$_.FullName}
        }
      } else {
        $files += [PSCustomObject]@{Path=$relative;File=$source}
      }
    }
    $files = @($files | Sort-Object Path -Unique)
    Write-Host ('Arquivos a atualizar: ' + $files.Count)
    Write-Host ('Backup dos arquivos substituidos: ' + $backup)
    Write-Host 'ATENCAO: o procedimento NAO altera o banco e NAO executa migrations.' -ForegroundColor Yellow
    $answer = Read-Host 'Confirmar atualizacao de arquivos com backup? (S/N)'
    if ($answer -notmatch '^[sS]$') {Write-Host 'Cancelado';exit 0}
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    foreach ($file in $files) {
      $destination = Join-Path $targetFull $file.Path
      $destDir = Split-Path -Parent $destination
      if (-not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
      if (Test-Path -LiteralPath $destination -PathType Leaf) {
        $relativeBackup = Join-Path $backup $file.Path
        $bDir = Split-Path -Parent $relativeBackup
        if (-not (Test-Path -LiteralPath $bDir)) {New-Item -ItemType Directory -Path $bDir -Force | Out-Null}
        Copy-Item -LiteralPath $destination -Destination $relativeBackup -Force -ErrorAction Stop
      }
      Copy-Item -LiteralPath $file.File -Destination $destination -Force -ErrorAction Stop
    }
    Write-Host ('[OK] Copiados ' + $files.Count + ' arquivos. Backup: ' + $backup) -ForegroundColor Green
    $php = Get-Command php -ErrorAction SilentlyContinue
    if ($php -and (Test-Path -LiteralPath (Join-Path $targetFull 'vendor\autoload.php'))) {
      Push-Location $targetFull
      try {
        & $php.Source artisan optimize:clear
        if ($LASTEXITCODE -ne 0) { Write-Warning 'Nao foi possivel limpar cache. Execute php artisan optimize:clear no terminal do ServBay.' }
      } finally {Pop-Location}
    } else {
      Write-Warning 'PHP ou vendor/autoload.php ausente. Configure o PHP do ServBay e rode INSTALAR-DEPENDENCIAS.bat ou composer install.'
    }
    Write-Host 'Atualize https://pousada.test com Ctrl+F5; teste /admin, /admin/paginas e /admin/calendario.' -ForegroundColor Green
    exit 0
} catch {
    Write-Host ('[ERRO] ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Se houve copia parcial, consulte o backup para restauracao; nunca recrie o banco para corrigir isso.' -ForegroundColor Yellow
    exit 1
}
