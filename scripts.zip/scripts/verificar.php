<?php
// Diagnostico basico: nao depende de Composer, Laravel, .env ou banco ativo.
$base = dirname(__DIR__);
$checks = [
    'PHP 8.3+' => PHP_VERSION_ID >= 80300,
    'Extensao PDO' => extension_loaded('PDO'),
    'Extensao pdo_mysql' => extension_loaded('pdo_mysql'),
    'Extensao mbstring' => extension_loaded('mbstring'),
    'Extensao fileinfo' => extension_loaded('fileinfo'),
    'composer.json' => is_file($base . '/composer.json'),
    'Laravel autoload (vendor)' => is_file($base . '/vendor/autoload.php'),
    'Arquivo .env' => is_file($base . '/.env'),
    'Assets e imagens' => is_file($base . '/public/assets/photos/hero-costa-serena.webp'),
];
foreach ($checks as $label => $ok) {
    printf("[%s] %s\n", $ok ? 'OK' : 'PENDENTE', $label);
}
if (in_array(false, $checks, true)) {
    echo "\nInstalacao incompleta. Consulte INSTALAR-DEPENDENCIAS.bat e LEIA-PRIMEIRO.md.\n";
    exit(1);
}
echo "\nVerificacoes basicas satisfeitas. Isso NAO valida o acesso ao banco nem a interface web.\n";
