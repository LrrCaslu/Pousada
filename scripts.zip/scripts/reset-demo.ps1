$ErrorActionPreference='Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
if(!(Test-Path '.env')){Write-Host 'Arquivo .env inexistente';exit 1}
if(Select-String -Path '.env' -Pattern '^APP_ENV=production$' -Quiet){Write-Host 'Reset bloqueado em producao.';exit 1}
Write-Warning 'ESTE COMANDO APAGARA TODAS AS TABELAS E DADOS NO BANCO DEFINIDO EM .env.'
$name=(Select-String -Path '.env' -Pattern '^DB_DATABASE=' | Select-Object -First 1).Line
Write-Host "Banco atual: $name"
$confirm=Read-Host 'Para continuar, digite exatamente APAGAR DEMO'
if($confirm -cne 'APAGAR DEMO'){Write-Host 'Operacao cancelada.';exit 1}
$php = (Get-Command php -ErrorAction SilentlyContinue).Source
if(!$php){$php=Read-Host 'Caminho completo do php.exe';if(!(Test-Path $php)){exit 1}}
& $php 'artisan' 'migrate:fresh' '--seed' '--force'
exit $LASTEXITCODE
