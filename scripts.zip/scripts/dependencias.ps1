$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
function Fail($message) { Write-Host "`n[ERRO] $message" -ForegroundColor Red; exit 1 }
function Run($command, $arguments) {
  Write-Host "`n> $command $($arguments -join ' ')" -ForegroundColor Cyan
  & $command @arguments
  if ($LASTEXITCODE -ne 0) { Fail "Comando falhou: $command" }
}
Write-Host '=================================================' -ForegroundColor Green
Write-Host ' Pousada Costa Serena - Dependencias Laravel' -ForegroundColor Green
Write-Host '=================================================' -ForegroundColor Green
if (!(Test-Path 'artisan') -or !(Test-Path 'composer.json')) { Fail 'Execute na pasta raiz do projeto (contendo artisan e composer.json).' }
$phpCmd=Get-Command php -ErrorAction SilentlyContinue
if (!$phpCmd) {
  $typed=Read-Host 'Nao achei php no PATH. Informe o caminho COMPLETO de php.exe do ServBay'
  if (!(Test-Path -LiteralPath $typed)) { Fail 'php.exe nao encontrado. Ative PHP no ServBay.' }
  $php=$typed
} else { $php=$phpCmd.Source }
Run $php @('-v')
if (!(Get-Command composer -ErrorAction SilentlyContinue)) {
  Write-Host 'Composer nao encontrado no PATH.' -ForegroundColor Yellow
  Write-Host 'Instale o Composer 2 em https://getcomposer.org/download/ e associe-o ao PHP 8.3+ do ServBay.'
  Write-Host 'Feche e abra novamente este instalador apos instalar o Composer.'
  Fail 'A pasta vendor depende do Composer. Nenhum arquivo de terceiros foi inventado.'
}
Write-Host "`n[1/4] Criando a pasta vendor com Composer (exige internet na primeira instalacao)..." -ForegroundColor Green
Run 'composer' @('install', '--no-interaction','--prefer-dist')
if (!(Test-Path -LiteralPath 'vendor/autoload.php')) { Fail 'Composer terminou mas vendor/autoload.php continua ausente.' }
Write-Host '[2/4] Verificando configuracao local...' -ForegroundColor Green
if (!(Test-Path '.env')) {
  Copy-Item '.env.example' '.env'
  Write-Host '[OK] .env criado; verifique a conexao MySQL antes de executar migrations.'
} else { Write-Host '[OK] .env ja existe e foi preservado.' }
$key=(Get-Content '.env' | Where-Object { $_ -match '^APP_KEY=' } | Select-Object -First 1)
if (!$key -or $key -eq 'APP_KEY=') {
  Write-Host '[3/4] Criando chave para uma instalacao nova...' -ForegroundColor Green
  Run $php @('artisan','key:generate')
} else {Write-Host '[3/4] APP_KEY existente preservada.' -ForegroundColor Green}
Write-Host '[4/4] Limpando caches do Laravel...' -ForegroundColor Green
Run $php @('artisan','optimize:clear')
Write-Host "`n[OK] Dependencias instaladas. vendor/autoload.php existe." -ForegroundColor Green
Write-Host 'Acesse seu site no ServBay. Se o banco ainda nao existe, rode install.bat.' -ForegroundColor Green
exit 0
