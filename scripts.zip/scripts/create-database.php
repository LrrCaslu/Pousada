<?php
/** Creates only the configured local database. No hardcoded MySQL credentials. */
require dirname(__DIR__).'/vendor/autoload.php';
Dotenv\Dotenv::createImmutable(dirname(__DIR__))->safeLoad();
$host=$_ENV['DB_HOST']??'127.0.0.1';$port=$_ENV['DB_PORT']??'3306';$name=$_ENV['DB_DATABASE']??'';
$user=$_ENV['DB_USERNAME']??'root';$password=$_ENV['DB_PASSWORD']??'';
if(!preg_match('/^[a-zA-Z0-9_]+$/D',$name)){fwrite(STDERR,"Nome de banco de dados invalido.\n");exit(1);}
try {
 $pdo=new PDO("mysql:host=$host;port=$port;charset=utf8mb4",$user,$password,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
 $pdo->exec('CREATE DATABASE IF NOT EXISTS `'.$name.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
 echo "Banco criado ou existente: $name\n";
} catch(Throwable $e){fwrite(STDERR,"Nao foi possivel criar o banco automaticamente. Crie-o no ServBay/phpMyAdmin ou revise usuario e permissoes.\nDetalhe: ".$e->getMessage()."\n");exit(1);}
