$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
function Abort($message) { Write-Host "[ERRO] $message" -ForegroundColor Red; exit 1 }
function Run($command, $arguments) { Write-Host "`n> $command $($arguments -join ' ')" -ForegroundColor Cyan; & $command @arguments; if($LASTEXITCODE -ne 0) { Abort "Falha ao executar $command" } }
Write-Host "=== Pousada Costa Serena / Instalacao local ServBay ===" -ForegroundColor Green
$phpCmd = Get-Command php -ErrorAction SilentlyContinue
if(!$phpCmd) { $typed = Read-Host 'Caminho completo para php.exe do ServBay'; if(!(Test-Path $typed)) { Abort 'PHP nao encontrado.' }; $phpCmd = Get-Item $typed; $env:PATH = (Split-Path $typed) + ';' + $env:PATH }
$php = if($phpCmd -is [System.IO.FileInfo]) {$phpCmd.FullName} else {$phpCmd.Source}
Run $php @('-v')
if(!(Get-Command composer -ErrorAction SilentlyContinue)){Abort 'Composer nao encontrado. Instale o Composer e adicione-o ao PATH.'}
if(!(Get-Command npm -ErrorAction SilentlyContinue)){Write-Warning 'Node.js/npm nao encontrado. Os assets publicos ja incluidos no ZIP serao usados.'}
if(!(Test-Path '.env')) { Copy-Item '.env.example' '.env'; Write-Host '[OK] .env criado a partir do modelo.' } else { Write-Host '[OK] .env existente preservado.' }
$change = Read-Host 'Configurar parametros de conexao MySQL no .env agora? (S/N)'
if($change -match '^[sS]') {
 $defaults = @{ 'DB_HOST'='127.0.0.1';'DB_PORT'='3306';'DB_DATABASE'='pousada_costa_serena';'DB_USERNAME'='root' }
 foreach($key in $defaults.Keys) {
   $v = Read-Host "$key [$($defaults[$key])]"
   if([string]::IsNullOrWhiteSpace($v)){ $v=$defaults[$key] }
   if($key -eq 'DB_DATABASE' -and $v -notmatch '^[A-Za-z0-9_]+$') { Abort 'Nome de banco invalido.' }
   $content = Get-Content '.env' -Raw
   $escaped = $v.Replace('\','\\').Replace('"','\"')
   $line = $key + '="' + $escaped + '"'
   $content = [regex]::Replace($content, '(?m)^' + $key + '=.*$', [System.Text.RegularExpressions.MatchEvaluator]{param($m) $line})
   [System.IO.File]::WriteAllText((Join-Path (Get-Location) '.env'), $content,[System.Text.UTF8Encoding]::new($false))
 }
 $secret = Read-Host 'DB_PASSWORD (vazio para nenhuma senha)' -AsSecureString
 $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
 try {$plaintext=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
 $content = Get-Content '.env' -Raw
 $pw=$plaintext.Replace('\','\\').Replace('"','\"')
 $line='DB_PASSWORD="' + $pw + '"'
 $content=[regex]::Replace($content,'(?m)^DB_PASSWORD=.*$',[System.Text.RegularExpressions.MatchEvaluator]{param($m) $line})
 [System.IO.File]::WriteAllText((Join-Path (Get-Location) '.env'),$content,[System.Text.UTF8Encoding]::new($false))
 $plaintext=$null;$pw=$null
}
Write-Host '[1/6] Dependencias PHP (Composer)' -ForegroundColor Green
Run 'composer' @('install','--no-interaction','--prefer-dist')
Write-Host '[2/6] Chave da aplicacao' -ForegroundColor Green
$key=(Get-Content '.env' | Where-Object { $_ -match '^APP_KEY=' } | Select-Object -First 1)
if($key -eq 'APP_KEY=' -or !$key){Run $php @('artisan','key:generate','--force')}
Write-Host '[3/6] Criacao do banco (MySQL deve estar ativo no ServBay)' -ForegroundColor Green
Run $php @('scripts/create-database.php')
Write-Host '[4/6] Migrations e seeders' -ForegroundColor Green
Run $php @('artisan','migrate','--force')
$seed = Read-Host 'Popular com usuarios de teste e dados ficticios? (S/N)'
if($seed -match '^[sS]'){Run $php @('artisan','db:seed','--force')}
Write-Host '[5/6] Compilando frontend com npm' -ForegroundColor Green
if(Get-Command npm -ErrorAction SilentlyContinue) {
 Run 'npm' @('install','--no-audit','--no-fund')
 Run 'npm' @('run','build')
} else { Write-Host '[INFO] Compilacao npm ignorada: recursos locais em public/assets continuam disponiveis.' }
Write-Host '[6/6] Storage publico' -ForegroundColor Green
& $php 'artisan' 'storage:link'
if($LASTEXITCODE -ne 0){Write-Warning 'O link storage falhou. Verifique permissao para criar symlinks no Windows. Imagens demo estaticas permanecem acessiveis.'}
Write-Host 'CONCLUIDO. Configure no ServBay um site Apache com DocumentRoot na pasta public.' -ForegroundColor Green
Write-Host 'URL sugerida: http://pousada.test | Admin: /admin | Hospede: /minha-conta'
exit 0
