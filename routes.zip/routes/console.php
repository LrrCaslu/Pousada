<?php
use Illuminate\Support\Facades\Artisan;
Artisan::command('pousada:status', function () {
    $this->info('Pousada Costa Serena: aplicação carregada.');
});
